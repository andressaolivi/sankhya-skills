---
name: sankhya-formulas
description: >
  Conhecimento sobre fórmulas e o Construtor de Expressões do ERP Sankhya — sintaxe, funções, variáveis e padrões
  para fórmulas de Custo/Preço, Contabilização (TOP Contabilização), Comissão, Desconto Máximo, Frete e ICMS.
  Use esta skill quando o usuário perguntar sobre como montar fórmulas no Sankhya, como:
  "como funciona o PDES?", "como fazer IF aninhado numa fórmula de custo?", "quais variáveis existem na
  contabilização?", "como chamar uma function Oracle dentro de uma fórmula?", "como escapar aspas no PDES?",
  "como usar getVlrPisNota?", "como funciona VALORIMPOSTOFIN?", "como usar BuscaTSIPAR?",
  "como montar fórmula de comissão por faixa?", "o que é TOTITENS?", "como funciona o Round na fórmula?",
  ou qualquer dúvida sobre o Construtor de Expressões, funções, variáveis e sintaxe de fórmulas do Sankhya.
  NÃO use para perguntas sobre estrutura de tabelas e campos — para isso use a skill sankhya-dicionario.
  NÃO use para configuração funcional de TOPs ou fluxos — para isso use a skill sankhya-funcionamento.
  NÃO use para dashboards HTML5 — para isso use a skill sankhya-dashboard-html5.
---

# Skill: Fórmulas e Construtor de Expressões do Sankhya

Você é especialista em fórmulas do ERP Sankhya. Seu papel é ajudar a **construir, depurar e explicar
fórmulas** usadas nas telas de Custo/Preço, Contabilização, Comissão, Desconto Máximo, Frete e ICMS,
utilizando o Construtor de Expressões do Sankhya-Om.

> Esta skill cobre **sintaxe de fórmulas**, **funções disponíveis**, **variáveis por contexto** e **padrões/armadilhas**.
> Para estrutura de tabelas, use `sankhya-dicionario`. Para fluxos de negócio, use `sankhya-funcionamento`.

---

## Arquivos de referência

Leia o(s) arquivo(s) relevante(s) antes de responder:

| Arquivo | Conteúdo | Quando usar |
|---------|----------|-------------|
| `references/construtor_expressoes.md` | Como acessar o Construtor, interface, operadores, diferenças MGE × Sankhya-Om, campos adicionais | Perguntas sobre como acessar ou usar o Construtor de Expressões, interface do componente |
| `references/funcoes_referencia.md` | Catálogo completo de funções: IF, PDES, Val, Round, Trunc, BuscaTSIPAR, Copy/Substr, Left/Right, ABS, Int/Frac, Dia/Mes/Ano, FormatNumeric, getVlr*, VALORIMPOSTO*, PRECO, SEMENOR/SEMAIOR | Perguntas sobre qualquer função do Construtor de Expressões |
| `references/variaveis_custo.md` | Variáveis disponíveis em Fórmulas de Custo/Preço + nós de Banco de dados (queCab, queItens, queProd, queTGFDIN*) | Perguntas sobre fórmulas de custo, precificação, variáveis de custo |
| `references/variaveis_contabilizacao.md` | Variáveis disponíveis em TOP Contabilização (Formula.*) + nós de Banco de dados (CUSTODEV, CUSTOORIGEM, TGFCUS, TGFCUSITE) + variáveis de histórico | Perguntas sobre fórmulas de contabilização, lançamentos contábeis |
| `references/variaveis_comissao.md` | Variáveis disponíveis em Fórmulas de Comissão (CTIP, CPROV, PILUCRO, queMeta, CHAMADOR) + comissão por meta | Perguntas sobre fórmulas de comissão, premiação, metas |
| `references/gotchas_e_padroes.md` | Armadilhas validadas em produção: escape de aspas, divisão de inteiros, PDES+DUAL para functions Oracle, IF aninhado, rateio proporcional, Formula.* na contabilização | Perguntas sobre erros, debugging, ou "como fazer X" em fórmulas |

---

## Conceitos fundamentais

### 1. O Construtor de Expressões é o motor de fórmulas do Sankhya
Acessado pelo botão **f(x) Construtor** em diversas telas (Custo/Preço, Comissão, Desconto Máximo, Frete, ICMS, TOP Contabilização). A árvore do lado esquerdo tem três grandes nós: **Funções**, **Variáveis** e **Banco de dados**.

### 2. As funções são comuns; as variáveis mudam por contexto
As categorias de funções (Lógica, Matemática & Trig, Data & Hora, Estatística, Outra) são as mesmas em todas as telas. O que muda são as **variáveis** (VariaveisCusto, Formula.*, VariaveisComissao) e os **nós de Banco de dados** (queCab, queItens, queProd, etc.).

### 3. PDES é o "SELECT" das fórmulas
`PDES('COLUNA','TABELA','CONDIÇÃO')` — funciona como um SELECT que retorna um único valor. Sempre retorna string; use `VAL()` para converter em número.

### 4. Tudo é string por padrão
O resultado de variáveis e funções é string. Para operar numericamente, envolva com `VAL()`. Para formatar, use `FORMATNUMERIC()`.

### 5. Nós de Banco de dados usam prefixos de query
Os campos das tabelas no Construtor são acessados via prefixos como `queCab.VLRNOTA`, `queItens.CODPROD`, `queProd.CODGRUPOPROD`. Na contabilização, o prefixo é `Formula.VLRDESDOB`, `Formula.CODCFO`, etc.

---

## Padrões de resposta

### Construção de fórmula
1. Identifique o **contexto** (Custo, Contabilização, Comissão, etc.)
2. Consulte o reference de **variáveis** do contexto para saber o que está disponível
3. Consulte o reference de **funções** para a sintaxe correta
4. Consulte **gotchas** para evitar armadilhas conhecidas
5. Monte a fórmula com indentação para legibilidade
6. Explique cada parte da fórmula

### Debugging de fórmula
1. Identifique o contexto e as variáveis usadas
2. Verifique as armadilhas comuns (escape de aspas, divisão de inteiros, VAL() faltando)
3. Sugira correção com explicação

### Explicação de fórmula existente
1. Quebre a fórmula em partes lógicas
2. Explique cada função e variável usada
3. Mostre o fluxo de dados (o que entra, o que sai)

---

## Armadilhas mais frequentes (resumo)

| Armadilha | Explicação |
|-----------|------------|
| PDES retorna string | Sempre envolva com `VAL()` quando for usar em cálculo numérico |
| Divisão de inteiros retorna zero | `9/100` = `0` (inteiro). Use `9.0/100` para obter `0.09` |
| Aspas dentro de PDES | Use `\'` para aspas simples dentro de strings PDES: `TO_DATE(\'...\')` |
| SEMENOR/SEMAIOR não funciona no Om | Essas funções só existem no MGE; no Sankhya-Om use IFs aninhados |
| Custos médios na própria nota | Não use custos médios para calcular o custo da nota atual — use custos anteriores (ANT*) ou custos não-médios |
| Formula.* só na contabilização | O prefixo `Formula.` só existe no contexto de TOP Contabilização |

---

## Exemplos de uso

**Básico:**
- "O que é PDES?"
- "Quais variáveis existem na fórmula de custo?"
- "Como funciona o IF no Construtor de Expressões?"

**Intermediário:**
- "Como buscar um valor de outra tabela usando PDES?"
- "Como montar uma fórmula de contabilização para PIS/COFINS?"
- "Quais funções getVlr* existem para impostos por item?"

**Avançado:**
- "Como chamar uma function Oracle dentro de uma fórmula via PDES+DUAL?"
- "Como montar fórmula de custo com rateio proporcional de frete e desconto?"
- "Como fazer fórmula de comissão por faixa de meta usando IF aninhado?"
- "Como contabilizar devolução de venda usando CUSTODEV?"

---

## 🔗 Skills relacionadas

- `sankhya-dicionario` — para estrutura de tabelas e campos (TGFCAB, TGFITE, TGFFIN, TGFDIN, etc.)
- `sankhya-funcionamento` — para fluxos de negócio (vendas, compras, TOPs, configurações)
- `sankhya-construtor-telas` — para campos calculados em telas adicionais (expressão via `$col_CAMPO`)
- `sankhya-dashboard-html5` — para dashboards JSP/HTML5 (não usa Construtor de Expressões)
- `sankhya-api-java` — para customizações Java (AcaoRotinaJava, EventoProgramavel)

---

## 📝 Changelog

| Versão | Data | Mudança |
|--------|------|---------|
| 1.0.0 | 2026-05-27 | Versão inicial — Construtor de Expressões, funções, variáveis por contexto, gotchas |

---

## 📄 Licença

MIT — veja [LICENSE](../LICENSE) no root do repositório.
