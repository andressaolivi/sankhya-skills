# Construtor de Expressões — Interface e Acesso

## Como acessar

O Construtor de Expressões é acessado pelo botão **f(x) Construtor** presente nas seguintes telas:

- Fórmulas de Custo/Preço
- Fórmulas de Comissão
- Fórmulas para Desconto Máximo
- Fórmulas para Cálculo de Frete
- Fórmulas para ICMS
- TOP Contabilização (campo "Fórmula" na grade de lançamentos contábeis)

## Interface do componente

O Construtor possui três áreas principais:

**Lado esquerdo — Árvore de categorias:**
Organizada em três grandes nós:
- **Funções:** Data & Hora, Estatística, Informação, Lógica, Matemática & Trig, Outra, Todas
- **Variáveis:** mudam conforme o contexto (VariaveisCusto, Formula, VariaveisComissao, etc.) + VariaveisGlobais
- **Banco de dados:** nós de query que expõem campos das tabelas (queCab, queItens, queProd, etc.)

Os itens podem ser adicionados à expressão com duplo clique ou arrastando.

**Centro — Operadores:**
Botões para inserção rápida dos operadores disponíveis:
`+`, `-`, `*`, `/`, `=`, `>`, `<`, `<>`, `=<`, `>=`, `NOT`, `AND`, `OR`, `(`, `)`

**Lado direito — Expressão do campo:**
Área de texto onde a fórmula é montada. Possui:
- Checkbox "Acrescentar no final da expressão" — quando marcado, novos itens vão para o final; quando desmarcado, vão na posição do cursor
- Botão "Limpar" — apaga toda a expressão
- Botões "Salvar" / "Cancelar"

## Variáveis Globais (comuns a todos os contextos)

Sempre disponíveis na árvore sob **Variáveis > VariaveisGlobais**:

| Variável | Descrição |
|----------|-----------|
| APPNAME | Nome da aplicação |
| APPSTARTDATE | Data de início da aplicação |
| APPSTARTTIME | Hora de início da aplicação |
| CODIGOUSUARIOLOGADO | Código do usuário logado |
| NOMEUSUARIOLOGADO | Nome do usuário logado |

## Diferenças MGE × Sankhya-Om

| Aspecto | MGE | Sankhya-Om |
|---------|-----|------------|
| Parâmetros de função | Sistema apresenta campos para preencher | Parâmetros vão para a expressão; preencher manualmente |
| Alterar valores de variáveis | Possível ao montar a expressão | Não disponível |
| Campos adicionais | Aparecem diretamente | Só aparecem se "Processar campo MGE/Mitra" estiver marcado no Dicionário de Dados |
| SEMENOR / SEMAIOR | Disponível | NÃO disponível — usar IF aninhado |

## Campos adicionais no Construtor

Campos adicionais (AD_*) podem aparecer de duas formas:

1. **Pelo nome do campo:** `AD_CAMPO1`, `CAMPOADICIONAL`
2. **Com sufixo da tabela:** `TGFCABAD_CAMPO1`, `TGFCABCAMPOADICIONAL` (quando dentro do nó `queCab`)

Para que campos adicionais do MGE apareçam no Sankhya-Om, é necessário marcar "Processar campo MGE/Mitra" na tela Dicionário de Dados.
