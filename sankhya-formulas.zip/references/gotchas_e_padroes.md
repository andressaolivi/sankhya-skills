# Gotchas e Padrões Avançados de Fórmulas no Sankhya

## Regra 1 — PDES retorna string: sempre use VAL()

**Contexto:** Qualquer fórmula que usa PDES em cálculo aritmético.
**Regra:** Envolver o PDES com `VAL()` quando o resultado será usado em operação numérica.
**Por quê:** O PDES sempre retorna string. Sem VAL(), operações aritméticas falham silenciosamente ou retornam resultados inesperados.

**Exemplo ruim:**
```
PDES('VLRDESCTOT','TGFCAB','NUNOTA='+NUNOTA) * 2
```

**Exemplo bom:**
```
VAL(PDES('VLRDESCTOT','TGFCAB','NUNOTA='+NUNOTA)) * 2
```

---

## Regra 2 — Divisão de inteiros retorna zero

**Contexto:** Qualquer fórmula que divide dois números inteiros para obter uma fração.
**Regra:** Sempre usar pelo menos um operando decimal (com `.0`) para forçar divisão de ponto flutuante.
**Por quê:** O avaliador interpreta `9/100` como divisão de inteiros → resultado `0`. Somente com um operando decimal (`9.0/100`) retorna `0.09`.

**Exemplo ruim:**
```
queItens.VLRTOT * (9/100)
```
Resultado: `0` (porque 9/100 = 0 em divisão inteira)

**Exemplo bom:**
```
queItens.VLRTOT * (9.0/100)
```
Resultado: valor correto com 9%

---

## Regra 3 — Escape de aspas dentro do PDES

**Contexto:** Quando a condição do PDES contém funções SQL que exigem aspas simples internas (TO_CHAR, TO_DATE, etc.).
**Regra:** Usar `\'` para aspas simples dentro de strings do PDES.
**Por quê:** O avaliador de fórmulas usa aspas simples como delimitadores de string. Aspas internas sem escape quebram o parsing.

**Exemplo ruim:**
```
PDES('SUM(PREVREC)','TGFMET','TO_CHAR(DTREF,'MM')='+MES(queCab.DTNEG))
```
Erro: o sistema interpreta `'TO_CHAR(DTREF,'` como fim da string.

**Exemplo bom:**
```
PDES('SUM(PREVREC)','TGFMET','TO_CHAR(DTREF,\'MM\')='+MES(queCab.DTNEG))
```

### Padrão para datas com TO_DATE:
```
PDES('MINHA_FUNC(param, TO_DATE(\'' + queCab.DTENTSAI + '\', \'YYYY/MM/DD\'))', 'DUAL', '1=1')
```

---

## Regra 4 — SEMENOR/SEMAIOR não existem no Sankhya-Om

**Contexto:** Fórmulas de comissão por faixa migradas do MGE.
**Regra:** Substituir por IFs aninhados.
**Por quê:** Essas funções existem apenas no MGE. No Om, causam erro.

**Padrão equivalente com IF:**
```
-- Faixas: <80%=0, <85%=1%, <90%=2%, <95%=3%, <100%=4%, >=100%=5%
IF(cobertura < 80, 0,
  IF(cobertura < 85, vlr * 0.01,
    IF(cobertura < 90, vlr * 0.02,
      IF(cobertura < 95, vlr * 0.03,
        IF(cobertura < 100, vlr * 0.04,
          vlr * 0.05)))))
```

---

## Regra 5 — Custos médios não podem calcular o custo da própria nota

**Contexto:** Fórmulas de Custo/Preço.
**Regra:** Para calcular o custo da nota atual, usar custos anteriores (ANT*) ou custos não-médios (CUSSEMICM, CUSCOMICM).
**Por quê:** Os custos médios (CUSMED*) dependem da nota em questão, criando referência circular.

**Exemplo ruim:**
```
CUSMEDSEMICM * queItens.QTDNEG   -- referência circular!
```

**Exemplo bom:**
```
ANTCUSMEDSEMICM * queItens.QTDNEG   -- usa custo médio anterior
CUSSEMICM * queItens.QTDNEG         -- usa custo de entrada (não-médio)
```

---

## Regra 6 — Formula.* só existe na contabilização

**Contexto:** Confusão ao copiar fórmulas entre contextos diferentes.
**Regra:** O prefixo `Formula.` só funciona no contexto de TOP Contabilização. Em Custo/Preço usa-se variáveis diretas (TOTITENS, VLRICM) e nós de banco (queCab., queItens.). Em Comissão, usa-se as variáveis de comissão (CTIP, CPROV) e os mesmos nós de banco.
**Por quê:** Cada contexto de fórmula tem sua própria árvore de variáveis.

---

## Regra 7 — Rateio proporcional: padrão correto

**Contexto:** Distribuir valores do cabeçalho (frete, despesas, desconto) proporcionalmente aos itens.
**Regra:** Usar o padrão `(queCab.VALOR / TOTITENS) * queItens.VLRTOTLIQ`.
**Por quê:** TOTITENS é o denominador correto pois representa o valor total de todos os itens sem as parcelas do cabeçalho.

**Padrão genérico:**
```
-- Rateio do frete por item
(queCab.VLRFRETE / TOTITENS) * queItens.VLRTOTLIQ

-- Rateio do desconto total por item
(queCab.VLRDESCTOT / TOTITENS) * queItens.VLRTOTLIQ

-- Rateio de outras despesas por item
(queCab.VLROUTROS / TOTITENS) * queItens.VLRTOTLIQ
```

---

## Regra 8 — Chamando Functions Oracle via PDES+DUAL

**Contexto:** Quando é necessário executar uma function customizada do banco dentro de uma fórmula.
**Regra:** Usar o padrão `PDES('FUNCTION(params)', 'DUAL', '1=1')`.
**Por quê:** O PDES aceita qualquer expressão SQL válida na coluna, e `DUAL` é a tabela dummy do Oracle.

**Padrão:**
```
VAL(PDES('MINHA_FUNCTION(' + queItens.CODPROD + ')', 'DUAL', '1=1'))
```

**Com NVL para proteger contra nulo:**
```
VAL(PDES('NVL(MINHA_FUNCTION(' + queItens.CODPROD + '), 0)', 'DUAL', '1=1'))
```

**Com data (escape de aspas):**
```
VAL(PDES('MINHA_FUNCTION(' + queItens.CODPROD + ', TO_DATE(\'' + queCab.DTENTSAI + '\', \'YYYY/MM/DD\'))', 'DUAL', '1=1'))
```

---

## Regra 9 — IF aninhado: simular CASE WHEN

**Contexto:** Quando a fórmula precisa de lógica condicional com múltiplas ramificações.
**Regra:** Aninhar o IF no terceiro argumento (valor_se_falso) para criar uma cadeia de condições.
**Por quê:** O Construtor de Expressões não possui CASE WHEN nativo; o IF é a única função lógica condicional.

**Padrão:**
```
IF(<condição_1>, <resultado_1>,
  IF(<condição_2>, <resultado_2>,
    IF(<condição_3>, <resultado_3>,
      <resultado_default>)))
```

**Dica de legibilidade:** Indentar cada nível de IF para facilitar a leitura e manutenção.

---

## Regra 10 — Contabilização de itens × cabeçalho

**Contexto:** TOP Contabilização — variáveis VLRIPI, VLRICMS, VLRSUBST, VLRDESC buscam em TGFCAB (cabeçalho). Para contabilizar por item, usar variáveis de item.
**Regra:** Se a contabilização precisa discriminar por item (CFO dos itens, Contas do Produto), usar as variáveis Formula.VLRTOTITEM, Formula.VLRITEM, Formula.VLRIPIITEM, Formula.VLRICMSITEM, Formula.VLRDESCITEM.
**Por quê:** As variáveis sem sufixo "ITEM" buscam valores totalizados do cabeçalho.

---

## Regra 11 — Consultas Auxiliares na contabilização

**Contexto:** TOP Contabilização com fórmulas complexas que precisam de dados adicionais.
**Regra:** Usar o campo "Consultas Auxiliares" para referenciar SQLs salvos no Repositório de Arquivos, separados por vírgula. Acessar resultados com `GETCOLUNACONSULTA` ou `GETCOLUNACONSULTACOMCHAVEAUX`.
**Por quê:** Permite trazer dados que não estão disponíveis nas variáveis padrão.

Exemplo no campo Consultas Auxiliares:
```
queryImposto.sql, queryImpostoPis.sql, queryImpostoCofins.sql
```

---

## Regra 12 — Campo "Number" nas funções getVlr*

**Contexto:** Ao usar getVlrPisNota, getVlrCofinsNota, etc. no Construtor de Expressões.
**Regra:** O campo "Number" gerado na expressão é apenas informativo e deve ser **removido** antes de salvar.
**Por quê:** Se não removido, a fórmula pode gerar erro ou resultado incorreto.
