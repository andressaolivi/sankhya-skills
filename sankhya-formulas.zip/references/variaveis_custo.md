# Variáveis do Construtor de Expressões — Fórmulas de Custo/Preço

## Tela de acesso
Módulo: Comercial > Avançado > Fórmulas de Custo/Preço

## Variáveis disponíveis (VariaveisCusto)

### Variáveis de valor da nota e itens

| Variável | Descrição | Fórmula/Origem |
|----------|-----------|----------------|
| TOTITENS | Valor total dos itens na nota (sem frete, desconto total, juro, destaque, embalagem do cabeçalho) | `TGFCAB.VLRNota - TGFCAB.VLRSEG - TGFCAB.VLRDESTAQUE - TGFCAB.VLRJURO + TGFCAB.VLRDESCTOT + TGFCAB.VLRDESCSERV` (com ajustes para TIPIPIEMB, ISSRETIDO, TIPFRETE) |
| VLRITE | Valor unitário do item | `TGFITE.VlrUnit` |
| QTDITE | Quantidade negociada do item | `TGFITE.QtdNeg` |
| VLRXQTD | Valor unitário × quantidade | `TGFITE.VLRTOT` |
| VLRIPI | Valor do IPI total do item (dividir por QTDNEG para unitário) | `TGFITE.VlrIPI` |
| VLRSUB | Valor total da ST do item (dividir por QTDNEG para unitário) | `TGFITE.VlrSubst` |
| VLRICM | Valor do ICMS total na nota | Calculado com ajustes para ICMS frete, seguro, embalagem |
| VLRDESC | Valor do desconto | |
| VLRPRO | Valor do produto com IPI, ST e desconto por item | Calculado conforme CODCFO (entradas 111/211/1101/2101 não somam IPI) |

### Índices calculados

| Variável | Descrição | Fórmula |
|----------|-----------|---------|
| INDFRE | Índice de frete (frete ÷ valor da nota) | `TGFCAB.VLRFRETE / TGFCAB.VlrNota` (com ajustes por TIPFRETE) |
| INDDES | Índice de desconto | `TGFCAB.VLRDESCTOT / (TGFCAB.VlrNota + TGFCAB.VLRDESCTOT)` |
| INDTOT | Índice total (nota ÷ itens) | `curTotal / TotalItens` (com ajustes ISS, embalagem, frete) |
| INDICMS | Índice de ICMS | `ICMSTotal / TGFCAB.VlrICMS` |
| INDEXTRACOMICM | Índice extra com ICMS | |
| INDEXSTRASEMICM | Índice extra sem ICMS | |

### Alíquotas

| Variável | Descrição |
|----------|-----------|
| ALIQICM | Alíquota de ICMS da entrada (para crédito) |
| ALIQVENDA | Alíquota de ICMS provável de venda (simulação de saída dentro do estado) |

### Custos calculados

| Variável | Descrição |
|----------|-----------|
| CUSCOMICM | Custo com ICMS |
| CUSSEMICM | Custo sem ICMS |
| CUSMED | Custo médio |
| CUSMEDCOMICM | Custo médio com ICMS |
| CUSMEDSEMICM | Custo médio sem ICMS |
| CUSGER | Custo gerencial |
| CUSREP | Custo de reposição |
| CUSTOFIXO | Custo fixo (usa percentual das preferências do Gerente On-line) |
| CUSVAR | Custo variável |

### Custos anteriores (ANT*)

| Variável | Descrição |
|----------|-----------|
| ANTCUSCOMICM | Custo anterior com ICMS |
| ANTCUSSEMICM | Custo anterior sem ICMS |
| ANTCUSMED | Custo médio anterior |
| ANTCUSMEDCOMICM | Custo médio anterior com ICMS |
| ANTCUSMEDSEMICM | Custo médio anterior sem ICMS |
| ANTCUSGER | Custo gerencial anterior |
| ANTCUSREP | Custo de reposição anterior |
| ANTCUSVAR | Custo variável anterior |

**IMPORTANTE:** Custos médios NÃO podem ser usados no cálculo de custo da própria nota (dependem da nota em questão). Usar custos anteriores (ANT*) ou custos não-médios (CUSSEMICM).

### Totais

| Variável | Descrição |
|----------|-----------|
| TOTALCOMICM | Total com ICMS (parcialmente visível nos prints) |
| TOTALSEMICM | Total sem ICMS |

### Outros

| Variável | Descrição |
|----------|-----------|
| PRAZOMEDIO | Prazo médio do financeiro da nota |
| TAXAJURO | Taxa de juro (vem do parâmetro TAXAJURO) |
| CASASDECIMAIS | Número de casas decimais para quantidade |

---

## Nós de Banco de dados (Fórmulas de Custo/Preço)

Os nós abaixo expõem campos das tabelas do Sankhya. Cada nó corresponde a uma query interna que traz os campos relevantes para o contexto.

| Nó | Tabela base | Descrição |
|----|-------------|-----------|
| queCab | TGFCAB | Campos do cabeçalho da nota (VLRNOTA, VLRFRETE, VLRDESCTOT, TIPMOV, CODTIPOPER, DTENTSAI, DTNEG, etc.) |
| queItens | TGFITE | Campos dos itens (CODPROD, VLRUNIT, QTDNEG, VLRTOT, VLRICMS, VLRIPI, VLRSUBST, VLRDESC, ALIQICMS, CODCFO, VLRTOTLIQ, campos AD_*, etc.) |
| queProd | TGFPRO | Campos do produto (CODGRUPOPROD, TIPSUBST, COMVEND, etc.) |
| queEmp | TSIEMP | Campos da empresa |
| queGer | Gerente | Campos do gerente |
| queGrupo | Grupo | Campos do grupo |
| quePesoNota | Peso | Peso total da nota |
| queVend | TGFVEN | Campos do vendedor |
| queTOP | TGFTOP | Campos da TOP |
| queCustoDev | Custos de devolução | CUSMEDCOMICM, CUSMEDSEMICM, ENTRADACOMICM, ENTRADASEMICM |
| queCustoOrigem | Custos da nota de origem | Mesma estrutura do queCustoDev |

### Nós de impostos detalhados (TGFDIN)

| Nó | Imposto | Campos disponíveis |
|----|---------|-------------------|
| queTGFDINCOFINS | COFINS | ALIQUOTA, BASE, BASERED, CODIMP, CODINC, COMIVA, CST, DIGITADO, IVA, NUNOTA, PAUTA, PERCVLR, RETEMFIN |
| queTGFDINCSSL | CSLL | Mesma estrutura |
| queTGFDINICMS | ICMS | Mesma estrutura |
| queTGFDININSS | INSS | Mesma estrutura |
| queTGFDINIPI | IPI | Mesma estrutura |
| queTGFDINIRF | IRF | Mesma estrutura |
| queTGFDINISS | ISS | Mesma estrutura |
| queTGFDINPIS | PIS | Mesma estrutura |
| queTGFDINST | ST | Mesma estrutura |

### Uso dos nós na fórmula

Os campos são referenciados com o prefixo do nó:
```
queCab.VLRNOTA
queItens.CODPROD
queItens.VLRTOTLIQ
queProd.CODGRUPOPROD
queTGFDINCOFINS.BASE
```

---

## Parâmetros que influenciam o comportamento

| Parâmetro | Efeito |
|-----------|--------|
| AVALFCUSERRZERO | Quando ligado, fórmula de custo com erro retorna zero (em vez de erro) |
| TAXAJURO | Define a taxa de juro usada na variável TAXAJURO |
| TOPQTDZERO | TOPs que aceitam quantidade zero (carrega custos anteriores) |
| PERCCUSFIXO | Percentual de custo fixo (BuscaTSIPAR) |
