# Variáveis do Construtor de Expressões — Fórmulas de Comissão

## Tela de acesso
Módulo: Comercial > Avançado > Fórmulas de Comissão

## Campos da tela

- **Código:** identificação numérica (obrigatório, manual)
- **Descrição da Fórmula:** nomenclatura para identificar a fórmula
- **Histórico:** histórico de comissões (opcional)
- **Fórmula:** a expressão propriamente dita, montada via Construtor de Expressões

### Aba Região Própria Vendedor
Configuração principal da fórmula de comissão.

### Aba Integração
Habilitada pelo parâmetro `TRATAPREMIACAO`. Configura:
- **Evento:** evento pessoal para a fórmula
- **Tipo de Integração:** Financeiro, Folha ou Nenhuma

## Variáveis disponíveis

### Percentuais de comissão

| Variável | Descrição |
|----------|-----------|
| CTIP | % Comissão do Tipo de Negociação |
| CPROV | % Comissão do Vendedor no Cadastro de Produtos |
| CPROG | % Comissão do Gerente |
| CVGP | % Comissão por grupo de perfil do Cadastro de Produtos |
| CUGP | % Comissão por grupo/perfil do Cadastro de Vendedores |

### Preços

| Variável | Descrição |
|----------|-----------|
| MIN | Preço mínimo pela tabela de preço mínimo da região do Parceiro |
| TAB | Preço de tabela |

### Rentabilidade

| Variável | Descrição |
|----------|-----------|
| PILUCRO | % Lucro do item (da Análise de Rentabilidade) |
| PIMARGCONTRIB | % Margem de contribuição do item |
| PNLUCRO | % Lucro da nota (da Análise de Rentabilidade) |
| PNMARGCONTRIB | % Margem de contribuição da nota |

### Identificação do chamador

| Variável | Valor | Descrição |
|----------|-------|-----------|
| CHAMADOR | N | Vendedor da Nota |
| CHAMADOR | V | Vendedor do Parceiro |
| CHAMADOR | A | Assessor do Parceiro |
| CHAMADOR | I | Vendedor dos Itens da Nota |
| CHAMADOR | E | Executante dos Itens da Nota |

### Totais de vendas

| Variável | Descrição |
|----------|-----------|
| QUETOTALVENDAS.VALOR | Somatório do VLRNOTA das linhas selecionadas na tela de cálculo de comissão para o vendedor |
| QUEMIX.QTD | Contagem de diferentes CODPROD das notas selecionadas (exclui USOPROD='D', matéria prima) |
| quePESONOTA.QTDITENSNOTA | Conta itens com USOPROD <> 'D'; se mesmo CODPROD duas vezes, conta duas vezes |

### Metas

| Variável | Descrição |
|----------|-----------|
| queMeta.PREVISTA | Meta prevista (módulo de Metas) |
| queMeta.REALIZADA | Meta realizada (módulo de Metas) |
| queMeta.CODMETA | Código da meta |
| queMeta.PREVDESP | Previsão de despesa |
| queMeta.QTDPREV | Quantidade prevista |
| queMeta.QTDREAL | Quantidade realizada |
| queMeta.REALDESP | Realização de despesa |

Habilitado pelo parâmetro `GOL-CODMETA`.

### Funções de totalização por item

| Função | Descrição |
|--------|-----------|
| queTotalVendasItem | Valor das vendas do vendedor nos itens |
| queTotalVendasGerItem | Valor das vendas do gerente e vendedores ligados, nos itens |

## Nós de Banco de dados (Fórmulas de Comissão)

| Nó | Descrição |
|----|-----------|
| queCab | Campos do cabeçalho (TGFCAB): TIPMOV, DTNEG, CODTIPOPER, etc. |
| queItens | Campos dos itens (TGFITE): VLRUNIT, QTDNEG, VLRTOT, VLRDESC, CODPROD, CODCFO, etc. |
| queProd | Campos do produto (TGFPRO): COMVEND, CODGRUPOPROD, etc. |
| queVend | Campos do vendedor (TGFVEN): COMVENDA, etc. |

## Funções especiais de comissão

### SEMENOR / SEMAIOR — Comissão por faixas

**ATENÇÃO: Disponíveis SOMENTE no MGE, NÃO no Sankhya-Om.**

Estrutura:
```
SEMAIOR(<referência>, <limite>, <valor>)
SEMENOR(<referência>, <limite1>, <valor1>, <limite2>, <valor2>, ..., <valor_default>)
```

Exemplo SEMENOR (faixas de comissionamento):
```
SEMENOR(resultmeta/prevmeta*100, 80,0, 85,1, 90,2, 95,3, 100,4, 5)
```
Leitura: se cobertura < 80% → 0%; se < 85% → 1%; se < 90% → 2%; etc.

**No Sankhya-Om, usar IFs aninhados para o mesmo resultado.**

### PRECO — Preço de tabela
```
Preco(<COD_TABELA>, <CODPROD>, <DATA>)
```
Exemplo: `Preco(1, queItens.CODPROD, queCab.DTNEG)`

## Considerações importantes

1. **Comissão dos itens:** os campos de comissão não devem ser usados no Pé da Nota; a comissão total é o somatório das comissões de cada item.

2. **Parâmetro USAPROCCALCCOM:** quando ligado, o sistema usa a procedure `STP_AVALIA_FORM_COMISSA` em vez das fórmulas desta tela.

3. **Parâmetro FECHCOMVEN:** quando ligado, o tipo de fechamento vem do Cadastro de Vendedores.

4. **Parâmetro TRATAPREMIACAO:** habilita a aba Integração e o cálculo de premiações.
