# Variáveis do Construtor de Expressões — TOP Contabilização

## Tela de acesso
Módulo: Contabilização > Arquivos > TOP Contabilização
Campo "Fórmula" na grade "Configurações p/ Lançamentos Contábeis".

## Variáveis disponíveis (Formula.*)

No contexto de contabilização, as variáveis são acessadas com o prefixo `Formula.` (diferente dos outros contextos que usam nomes diretos).

### Valores financeiros

| Variável | Descrição |
|----------|-----------|
| Formula.VLRDESDOB | Valor do desdobramento do título |
| Formula.VLRLANC | Valor do lançamento |
| Formula.VLRLANCCONTRAPART | Valor do lançamento de contrapartida |
| Formula.VLRMOEDA | Valor em moeda |
| Formula.VLRBAIXA | Valor da baixa (implícito, usado em filtros de baixas) |
| Formula.VLRJURO | Valor de juros |
| Formula.VLRJUROEMBUT | Valor de juros embutidos |
| Formula.VLRJUROMES | Valor de juros no mês |
| Formula.VLRJUROMES2 | Valor de juros no mês (segunda referência) |
| Formula.VLRMULTA | Valor de multa |
| Formula.VLRMULTAEMBUT | Valor de multa embutida |
| Formula.VLRMULTAMES | Valor de multa no mês |
| Formula.VLRVARCAMBIAL | Valor de variação cambial |
| Formula.VLRVARCAMBIALTOTAL | Valor total de variação cambial |
| Formula.VLRVARCAMBIALTOTALCONTRAPART | Variação cambial total da contrapartida |
| Formula.VLRVENDOR | Valor do vendor |
| Formula.VLRTARE | Valor da TARE |

### Impostos na nota

| Variável | Descrição |
|----------|-----------|
| Formula.VLRICMS | Valor do ICMS da nota (busca em TGFCAB) |
| Formula.VLRDESC | Valor do desconto da nota |
| Formula.VLRISS | Valor do ISS |
| Formula.VLRIRF | Valor do IRF |
| Formula.VLRINSS | Valor do INSS |
| Formula.VLRSTFCPINT | Valor ST FCP Interno |
| Formula.VLRCTB | Valor contábil |
| Formula.VLRCTBTARE | Valor contábil TARE |

### Impostos por item

| Variável | Descrição |
|----------|-----------|
| Formula.VLRTOTITEM | VLRTOT + VLRIPI + VLRSUBST – VLRDESC |
| Formula.VLRITEM | (QTDNEG × VLRUNIT) + VLRIPI + VLRSUBST - VLRDESC |
| Formula.VLRIPIITEM | Valor do IPI do item |
| Formula.VLRICMSITEM | Valor do ICMS do item |
| Formula.VLRDESCITEM | Valor do desconto do item |
| Formula.VLRREPREDITEM | Valor de redução de preço do item |
| Formula.VLRDESCEMBUT | Valor de desconto embutido |

### ICMS DIFAL/FCP

| Variável | Descrição |
|----------|-----------|
| Formula.VLRICMSDIFALDEST | ICMS DIFAL do destinatário |
| Formula.VLRICMSDIFALREM | ICMS DIFAL do remetente |
| Formula.VLRICMSFCP | ICMS FCP |
| Formula.VLRICMSFCPINT | ICMS FCP Interno |
| Formula.VLRICMSTARE | ICMS TARE |
| Formula.VLRICMSITEM | ICMS do item |
| Formula.DIFICMS | Diferencial de ICMS |
| Formula.ICMSRETENCAO | ICMS de retenção |

### Variáveis do livro fiscal (prefixo LIV)

| Variável | Descrição |
|----------|-----------|
| Formula.LIVBASEICMS | Base ICMS do livro |
| Formula.LIVBASEIPI | Base IPI do livro |
| Formula.LIVBASESUBSTIT | Base ST do livro |
| Formula.LIVVLRICMS | Valor ICMS do livro |
| Formula.LIVVLRICMSCOMPL | Complemento do ICMS |
| Formula.LIVVLRICMSDIFALDEST | DIFAL destino (livro) |
| Formula.LIVVLRICMSDIFALREM | DIFAL remetente (livro) |
| Formula.LIVVLRICMSFCP | FCP (livro) |
| Formula.LIVVLRICMSFCPINT | FCP Interno (livro) |
| Formula.LIVVLRIPI | Valor IPI (livro) |
| Formula.LIVVLRSTFCPINT | ST FCP Interno (livro) |
| Formula.LIVVLRSUBST | Valor ST (livro) |

### Variáveis IBS/CBS (Reforma Tributária)

| Variável | Descrição |
|----------|-----------|
| Formula.VBCIBSCBS | Base de cálculo IBS/CBS |
| Formula.VCBS | Valor CBS |
| Formula.VCBSMONO | CBS monofásico |
| Formula.VCBSMONORET | CBS monofásico retido |
| Formula.VCBSMONORETEN | CBS monofásico retenção |
| Formula.VCRDPRESCONSUSIBS | Crédito presumido consumo IBS |
| Formula.VCREDPRESCBS | Crédito presumido CBS |
| Formula.VCREDPRESIBS | Crédito presumido IBS |
| Formula.VDEVTRIBCBS | Devolução tributária CBS |
| Formula.VDEVTRIBIBSMUN | Devolução tributária IBS municipal |
| Formula.VDIFCBS | Diferencial CBS |
| Formula.VDIFIBSMUN | Diferencial IBS municipal |
| Formula.VDIFIBSUF | Diferencial IBS UF |
| Formula.VIBS | Valor IBS |
| Formula.VIBSMONO | IBS monofásico |
| Formula.VIBSMONORET | IBS monofásico retido |

### Alíquotas e bases

| Variável | Descrição |
|----------|-----------|
| Formula.ALIQICMS | Alíquota de ICMS |
| Formula.ALIQIPI | Alíquota de IPI |
| Formula.BASEICMS | Base de cálculo ICMS |
| Formula.BASEICMSTARE | Base ICMS TARE |
| Formula.BASERETENCAO | Base de retenção |
| Formula.BASERETENCAOSEMRED | Base de retenção sem redução |

### Datas

| Variável | Descrição |
|----------|-----------|
| Formula.DTBAIXA | Data da baixa |
| Formula.DTCONCILIACAO | Data de conciliação |
| Formula.DTLANC | Data do lançamento |
| Formula.DTMOV | Data de movimento |
| Formula.DTNEG | Data de negociação |
| Formula.DTRENEG | Data de renegociação |
| Formula.DTRENEG2 | Data de renegociação 2 |
| Formula.DTVENC | Data de vencimento |

### Códigos e identificadores

| Variável | Descrição |
|----------|-----------|
| Formula.CODPARC | Código do parceiro |
| Formula.CODPROJ | Código do projeto |
| Formula.CODTIPTIT | Código do tipo de título |
| Formula.CODTRIB | Código da tributação |
| Formula.CODCFO | Código da CFO |
| Formula.CODCTABCOINT | Código da conta bancária |
| Formula.CODCTACTB | Código da conta contábil |
| Formula.CODEMPBAIXA | Código da empresa da baixa |
| Formula.CTACODEMP | Código da empresa da conta |
| Formula.EMPCTABCOCONTRAPART | Empresa da conta de contrapartida |
| Formula.BCOCTA | Banco/conta |
| Formula.NUMNOTA | Número da nota |
| Formula.NUMDOC | Número do documento |
| Formula.NOSSONUM | Nosso número |
| Formula.NURENEGORIG | Número da renegociação original |

### Flags e tipos

| Variável | Descrição |
|----------|-----------|
| Formula.RECDESP | Receita (1) ou Despesa (-1) |
| Formula.RECDESPORIG | Receita/Despesa original |
| Formula.MBRECDESP | Movimento bancário receita/despesa |
| Formula.ENTSAI | Entrada/Saída |
| Formula.ORIGEM | Origem do lançamento |
| Formula.PROVISAO | Se é provisão |
| Formula.RATEADO | Se está rateado |
| Formula.TIPIPI | Tipo de IPI |
| Formula.TIPJURO | Tipo de juro |
| Formula.TIPMULTA | Tipo de multa |
| Formula.ISSRETIDO | ISS retido |
| Formula.IRFRETIDO | IRF retido |
| Formula.INSSRETIDO | INSS retido |
| Formula.ISENTASICMS | Isento de ICMS |
| Formula.ISENTASIPI | Isento de IPI |
| Formula.PROUSOPROD | Uso do produto |

### Outros

| Variável | Descrição |
|----------|-----------|
| Formula.HISTORICO | Histórico do lançamento |
| Formula.DESCRICAO | Descrição |
| Formula.DESPCART | Despesa de carteira |
| Formula.TAXAADM | Taxa administrativa |
| Formula.TOTPRODUTO | Total de produtos |
| Formula.TOTSERVICO | Total de serviços |
| Formula.TOTALJUROSVALORPRESENTE | Total juros a valor presente |
| Formula.JUROSVALORPRESENTE | Juros a valor presente |
| Formula.VALORPRESENTE | Valor presente |
| Formula.OUTRASICMS | Outras de ICMS |
| Formula.OUTRASIPI | Outras de IPI |
| Formula.FINCENCUS | Centro de custo do financeiro |
| Formula.FINCODEMP | Empresa do financeiro |
| Formula.FINCTABCO | Conta bancária do financeiro |
| Formula.FINVLRVARCAMBIAL | Variação cambial do financeiro |

### Variável queLOTE

No contexto de contabilização, também está disponível `queLOTE.CODEMP` (empresa do lote de contabilização).

---

## Nós de Banco de dados (TOP Contabilização)

| Nó | Descrição | Campos |
|----|-----------|--------|
| CUSTODEV | Custos da devolução de venda | CUSMEDCOMICM, CUSMEDSEMICM, ENTRADACOMICM, ENTRADASEMICM, ORDEM, QTD, QTDATENDIDA |
| CUSTOORIGEM | Custos da nota de origem (devolução de compra) | CUSMEDCOMICM, CUSMEDSEMICM, ENTRADACOMICM, ENTRADASEMICM |
| TGFCUS | Custos da nota | CUSMEDCOMICM, CUSMEDSEMICM, ENTRADACOMICM, ENTRADASEMICM |
| TGFCUSITE | Custos por item | CUSMEDCOMICM, CUSMEDSEMICM, ENTRADACOMICM, ENTRADASEMICM, ORDEM, QTD |

### Fórmulas de devolução

Para devolução de venda (custos da data da NF de venda original):
```
CUSTODEV.CUSMEDSEMICM * CUSTODEV.QTDATENDIDA
CUSTODEV.CUSMEDCOMICM * CUSTODEV.QTDATENDIDA
CUSTODEV.ENTRADASEMICM * CUSTODEV.QTDATENDIDA
CUSTODEV.ENTRADACOMICM * CUSTODEV.QTDATENDIDA
```

Para devolução de compra (custos da data da NF de compra original):
```
CUSTOORIGEM.CUSMEDSEMICM
CUSTOORIGEM.CUSMEDCOMICM
CUSTOORIGEM.ENTRADASEMICM
CUSTOORIGEM.ENTRADACOMICM
```

**Pré-requisitos para funcionamento:**
1. A nota de origem deve ter custos calculados
2. Os itens da devolução devem estar amarrados à nota de origem (TGFVAR)
3. Os custos retornados são unitários — multiplicar por QTDATENDIDA

---

## Variáveis de histórico (campo "Desc. Histórico")

| Variável | Descrição |
|----------|-----------|
| \|NF\| | Nota Fiscal |
| \|DN\| | Data da negociação |
| \|HH\| | Histórico (50 posições) |
| \|DV\| | Data de vencimento |
| \|DM\| | Data de movimento |
| \|DB\| | Data da baixa |
| \|ND\| | Número do documento |
| \|NS\| | Nosso número |
| \|NP\| | Nome/Razão Social do parceiro |
| \|RP\| | Nome/Razão Social do parceiro |
| \|RS\| | Razão Social do parceiro |
| \|NO\| | Nome do parceiro |
| \|NT\| | Número da transferência |
| \|CC\| | Conta corrente |
| \|CD\| | Descrição da conta |
| \|CR\| | Descrição do Centro de Resultado |
| \|OB\| | Observação da nota (50 posições) |
| \|DI\| | Descrição do produto/serviço |
| \|NA\| | Descrição da Natureza |
| \|PR\| | Identificação do Projeto |
| \|CT\| | Nome do Contato |
| \|CP\| | Código do Produto/Serviço |
| \|CE\| | Código da Empresa |
| \|NE\| | Nome da Empresa |
| \|DD\| | Desdobramento |
| \|ED\| | Espécie de documento |
| \|BB\| | Código do Bem baixado pela NF |
| \|NR\| | Número da NF referenciada |
| \|DC\| | Descrição da conta bancária de contrapartida |
| \|NSD\| | Série do documento fiscal |
| \|NC\| | Número do contrato |
| \|NCF\| | Número do conhecimento de frete |
| \|RSCE\| | Razão Social do Contato de Entrega |
| \|RSPT\| | Razão Social do Parceiro Transportadora |
| \|RSPD\| | Razão Social do Parceiro Destinatário |
| \|RSPR\| | Razão Social do Parceiro Remetente |

---

## Parâmetros que influenciam

| Parâmetro | Efeito |
|-----------|--------|
| HARMOCTXFORMULA | Quando ligado, expressões do construtor se tornam mais intuitivas |
| USANATXEMP | Influencia apresentação de "Natureza por Empresa" na conta contábil |
| USANATPROJ | Habilita opção "Natureza por Projeto" |
| NOMERAZAOPARC | Define se variáveis \|NP\| e \|RP\| trazem Nome ou Razão Social |
