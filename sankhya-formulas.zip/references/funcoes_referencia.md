# Funções do Construtor de Expressões — Referência Completa

## Funções Lógicas

### IF — Condição
```
IF(<CONDIÇÃO>, <VALOR_SE_VERDADEIRO>, <VALOR_SE_FALSO>)
```
Avalia a condição; se verdadeira retorna o segundo argumento, se falsa retorna o terceiro.

Exemplos genéricos:
```
IF(VLRDESDOB=VLRBAIXA, VLRDESDOB, 0)
IF(queCab.TIPMOV='V', 1, -1)
IF(queItens.VLRSUBST=0, queItens.VLRICMS/queItens.QTDNEG, 0)
```

Para simular múltiplas condições (CASE WHEN), aninhar IFs no terceiro argumento:
```
IF(<cond1>, <val1>,
  IF(<cond2>, <val2>,
    IF(<cond3>, <val3>, <val_default>)))
```

### TRUE / FALSE
Constantes booleanas para uso em expressões lógicas.

---

## Funções de Pesquisa

### PDES — Consulta ao banco de dados
```
PDES('<COLUNA>', '<TABELA(S)>', '<CONDIÇÃO>')
```
Funciona como um SELECT que **deve retornar um único valor**. Estrutura semelhante ao SQL.

**Regra fundamental:** PDES sempre retorna **string**. Use `VAL()` para converter em número.

Concatenação de parte fixa com variável usa `+`:
```
PDES('<COLUNA>', '<TABELA>', '<PARTE_FIXA>' + PARTE_VARIAVEL)
```

Exemplos genéricos:
```
-- Buscar nome do parceiro
PDES('NOMEPARC', 'TGFPAR', 'CODPARC=' + CODPARC)

-- Soma com condição
VAL(PDES('SUM(VLRICMS)', 'TGFITE', 'VLRSUBST=0 AND NUNOTA=' + NUNOTA))

-- PDES aninhado com IF
VAL(IF(PDES('ISSRETIDO','TGFCAB','NUNOTA='+NUNOTA)='S',
       PDES('VLRISS','TGFCAB','NUNOTA='+NUNOTA), 0))
```

**Chamando functions Oracle via PDES+DUAL:**
```
VAL(PDES('MINHA_FUNCTION(param1, param2)', 'DUAL', '1=1'))
```
Este padrão permite executar qualquer function do banco de dados dentro do avaliador de fórmulas. Para passar variáveis como parâmetros, concatenar com `+`:
```
VAL(PDES('MINHA_FUNCTION(' + queItens.CODPROD + ')', 'DUAL', '1=1'))
```

**NVL dentro do PDES** para tratar nulos:
```
VAL(PDES('NVL(MINHA_FUNCTION(params), 0)', 'DUAL', '1=1'))
```

### PDESPARAM
Variante parametrizada do PDES (disponível na árvore de funções).

### BuscaTSIPAR — Buscar valor de parâmetro do sistema
```
BuscaTSIPAR('<NOME_PARAMETRO>')
```
Retorna o valor armazenado em um parâmetro do sistema (TSIPAR). Útil para evitar hardcoding de percentuais em fórmulas.

Exemplos:
```
BuscaTSIPAR('PERCCUSFIXO')    -- Percentual de custo fixo
BuscaTSIPAR('PERCCOMISSAO')   -- Percentual de comissão
BuscaTSIPAR('TAXAJURO')       -- Taxa de juro
```

Pode-se criar parâmetros personalizados para armazenar valores usados em fórmulas.

### PRECO — Buscar preço de tabela
```
PRECO(<COD_TABELA>, <CODPROD>, <DATA>)
```
Retorna o preço de um produto em uma tabela de preços para uma data específica. Usado principalmente em fórmulas de comissão.

Exemplo:
```
Preco(1, queItens.CODPROD, queCab.DTNEG)
```

---

## Funções Matemáticas

### ABS — Valor absoluto
```
ABS(<VARIÁVEL>)
```
Retorna o módulo (valor sem sinal).

### ROUND — Arredondamento
```
ROUND(<VARIÁVEL>, <QTD_CASAS>)
```
Arredonda para o número de casas decimais indicado.
Exemplo: `ROUND(3.14159, 2)` → `3.14`; `ROUND(1.995, 2)` → `2.00`

### TRUNC — Truncamento
```
TRUNC(<VARIÁVEL>, <QTD_CASAS>)
```
Corta as casas decimais sem arredondar.
Exemplo: `TRUNC(3.14159, 2)` → `3.14`; `TRUNC(1.995, 2)` → `1.99`

### INT — Parte inteira
```
INT(<VARIÁVEL>)
```
Extrai a parte inteira de um número.

### FRAC — Parte fracionária
```
FRAC(<VARIÁVEL>)
```
Extrai a parte decimal de um número.

### DIV — Divisão inteira
Divisão que retorna apenas a parte inteira do resultado.

### FLOOR — Arredondamento para baixo
Arredonda para o inteiro imediatamente inferior.

### SQRT — Raiz quadrada
```
SQRT(<VARIÁVEL>)
```

### CALCSTR — Cálculo de string
Avalia uma expressão matemática representada como string.

### STRZERO — String com zeros à esquerda
Formata um número com zeros à esquerda até atingir o tamanho especificado.

---

## Funções de Formato de Dados

### VAL — Converter string em número
```
VAL(<EXPRESSÃO>)
```
Converte o resultado (que é string por padrão) em valor numérico. **Essencial** quando PDES é usado em cálculos.

Exemplo: `VAL(PDES('VLRDESCTOT','TGFCAB','NUNOTA='+NUNOTA))`

### FORMATNUMERIC — Formatar número
```
FORMATNUMERIC('<MASCARA>', <VALOR>)
```
Formata um valor numérico com máscara. Usada principalmente em relatórios e EDI.

Exemplo: `FORMATNUMERIC('###,###,##0.00', VLRNOTA)` → `13.900,66`

### COPY / SUBSTR — Extrair parte de texto
```
COPY(<VARIÁVEL>, <CARACTERE_INICIAL>, <NUM_CARACTERES>)
SUBSTR(<VARIÁVEL>, <CARACTERE_INICIAL>, <NUM_CARACTERES>)
```
Funcionam de forma idêntica. Extraem uma parte de uma string.

Exemplo (formatação de CEP):
```
COPY(CEP,1,2) + '.' + COPY(CEP,3,3) + '-' + COPY(CEP,6,3)
```

### LEFT / RIGHT — Extrair do início/fim
```
LEFT(<VARIÁVEL>, <NUM_CARACTERES>)
RIGHT(<VARIÁVEL>, <NUM_CARACTERES>)
```
LEFT pega os primeiros N caracteres; RIGHT pega os últimos N.

### STR — Converter para string
Converte um valor para representação de texto.

### PAD / PADR / PAE — Preenchimento
Completam string com espaços (PAD à direita, PADR à direita, PAE à esquerda).

### UPPER / LOWER — Maiúsculas/Minúsculas
Convertem texto para maiúsculas ou minúsculas.

### TRIM — Remover espaços
Remove espaços em branco no início e fim da string.

### SUBSTITUI — Substituir texto
Troca ocorrências de um texto por outro.

### REMOVERENTER — Remover quebras de linha
Remove caracteres de quebra de linha do texto.

### EXTENSO / EXTENSONRO — Valor por extenso
Converte número em texto por extenso.

### PRETTY — Formatação de texto
Formata texto com capitalização adequada.

### ESPACATEXTO — Espaçar texto
Adiciona espaços entre caracteres.

### COPYSEMPADR — Cópia sem padding
Copia texto removendo preenchimento.

---

## Funções de Data

### DIA / MES / ANO — Extrair partes de data
```
DIA(<VARIÁVEL_DATA>)
MES(<VARIÁVEL_DATA>)
ANO(<VARIÁVEL_DATA>)
```
Retornam dia, mês ou ano de uma data. MES retorna sem zero à esquerda (1-9); para formatar com zero, usar "Inteiro com zeros à esquerda" no Tipo do Campo.

### DATE — Data
Função de data.

### DATESYS — Data do sistema
Retorna a data atual do servidor.

### SOMADATA — Somar dias a uma data
Adiciona dias a uma data.

### TIME — Hora
Retorna hora atual.

### DDMMYYYY — Formatar data
Formata data no padrão DD/MM/YYYY.

### DTOC — Data para caractere
Converte data em string.

### CTOD — Caractere para data
Converte string em data.

### DIAEXT / MESEXT — Dia/Mês por extenso
Retorna o nome do dia da semana ou mês por extenso.

---

## Funções Estatísticas

### AVERAGE / COUNT / MAX / MIN / SUM
Funções de agregação padrão. Disponíveis na árvore de funções.

---

## Funções de Informação

### TYPEOF
Retorna o tipo de dado de uma variável.

---

## Funções de Impostos (disponíveis em Contabilização e Custo)

### Funções para Nota (nível cabeçalho)
```
getVlrPisNota(NUNOTA)
getVlrCofinsNota(NUNOTA)
getVlrCSLLNota(NUNOTA)
```
Retornam a soma do campo VALOR da TGFDIN para a nota, filtrando por CODIMP:
- CODIMP 6 → PIS
- CODIMP 7 → COFINS
- CODIMP 9 → CSLL

### Funções para Item (nível detalhe)
```
getVlrPisItem(NUNOTA, Sequencia)
getVlrCofinsItem(NUNOTA, Sequencia)
getVlrCSLLItem(NUNOTA, Sequencia)
getVlrICMSItem(NUNOTA, Sequencia)
getVlrIPIItem(NUNOTA, Sequencia)
getVlrICMSDifalDestItem(NUNOTA, Sequencia)
getVlrICMSDifalRemItem(NUNOTA, Sequencia)
getVlrICMSFCPItem(NUNOTA, Sequencia)
getVlrICMSFCPIntItem(NUNOTA, Sequencia)
getVlrSTFCPIntItem(NUNOTA, Sequencia)
getVlrSTItem(NUNOTA, Sequencia)
getVlrImpDin(...)
```

### VALORIMPOSTOFIN — Imposto do financeiro
```
VALORIMPOSTOFIN(<COD_IMP>, <NUFIN>, '<TIPO>')
```
Onde TIPO: `'B'` = base, `'V'` = valor, `'A'` = alíquota. Se COD_IMP = 0, soma todos os impostos.

Exemplo: `VALORIMPOSTOFIN(0, NUFIN, 'V')` → soma de todos os impostos do financeiro.

### VALORIMPOSTOCAB — Imposto do cabeçalho da nota
```
VALORIMPOSTOCAB(<COD_IMP>, <NUNOTA>, '<TIPO>')
```
Mesma lógica do VALORIMPOSTOFIN, mas busca na TGFIMN (impostos da nota).

Exemplo: `VALORIMPOSTOCAB(1, NUNOTA, 'B')` → base do ICMS da nota.

### VALORIMPOSTODIN — Imposto detalhado
```
VALORIMPOSTODIN(<COD_IMP>, <NUNOTA>, <COD_INC>, '<TIPO>')
```
Busca na TGFDIN. COD_INC = código de incidência (0 = geral, 1 = por produto, etc.).

### VALORIMPOSTO / IMPOSTONOTA / IMPOSTOS
Funções adicionais para acesso a impostos (disponíveis na árvore "Outra").

---

## Funções de Saldo e Estoque

### SALDO / SALDOBCO / SALDOCTA / SALDOEST
Funções para consultar saldos (financeiro, bancário, conta contábil, estoque).

### MOVTOEST
Função para movimento de estoque.

---

## Funções Específicas de Comissão

### SEMENOR / SEMAIOR — Comissão por faixas (SOMENTE MGE)
```
SEMAIOR(<referência>, <limite>, <valor>)
SEMENOR(<referência>, <limite>, <valor>)
```
**ATENÇÃO:** Estas funções NÃO estão disponíveis no Sankhya-Om. Para o Om, usar IF aninhado.

### Variáveis de comissão
Ver `variaveis_comissao.md` para a lista completa.

---

## Funções Diversas (categoria "Outra")

### ACUMULADOCTA
Acumula valores de conta contábil.

### BDGETVAR / BDSETVAR
Ler/gravar variáveis no banco de dados.

### MEMGETVAR / MEMSETVAR / MEMINCVAR / MEMEDTVAR
Ler/gravar/incrementar/editar variáveis em memória durante a avaliação da fórmula.

### BUSCALAUDO
Buscar informações de laudo.

### BUSCAVALORFAIXA
Buscar valor por faixa.

### GETCOLUNACONSULTA / GETCOLUNACONSULTACOMCHAVEAUX
Buscar coluna de consultas auxiliares (usada em TOP Contabilização com campo "Consultas Auxiliares").

### GETC1 / GETC2 / GETC3
Buscar contas contábeis (conta 1, 2, 3).

### LOTEINFO
Informações do lote de contabilização.

### PAGINA / LINHA
Controle de paginação (usadas em formatação de EDI/relatórios).

### PEDIDOS
Acesso a informações de pedidos.

### PENSAOCREDITO / PENSAODEBITO
Funções do módulo Pessoal (pensão alimentícia).

### PESODESCONTAR
Peso para desconto (módulo Pessoal).

### SIMNAO
Retorna 'Sim' ou 'Não' baseado em valor booleano.

### VARIAVEL / VARIAVELPORNOME
Acesso a variáveis por código ou nome.

### VALORNATUREZA
Buscar valor da natureza de receita/despesa.

### VLRBONIFICACAO
Valor de bonificação.

### ULTVLR
Último valor.

### TROCAESP
Troca de espaços.

### FORMATATEXTO
Formatação de texto com máscara.

### FTEMNALISTA
Verifica se item está em uma lista.

### Funções F* (módulo Pessoal/Folha)
FBEDTPAG, FBEIR, FBIND, FBL, FBM, FBMS, FBE, FCALCINFREND, FCALCRAIS, FCONVENIO, FCONVENIODPD, FDIASAFAMOTIVO, FDIASDESCDSR, FDIASEMANA, FDIASNAOUTEIS, FDIASSUBSTFUNC, FDIASTRAB, FDIASUTEIS, FFERPRO, FGRATIFICACAO, FHORASOCORRENCIA, FMEDEVE, FMESACUM, FNIVESC, FQD, FQTDANOS, FROUND6, FSOMACU, FSOMACUHR, FSOMACUINFREND, FSOMACURAIS, FSOMAEVE, FSOMAMES, FSTRDAT, FSTRDE, FTF, FTIRACAR, FVALORCONVENIO, FVALORCONVENIODPD, FVALORDSR, FVLRSUBSTFUNC, TRUNCFOL — específicas do módulo Pessoal+/Folha de Pagamento.

### SUVINILBASE / SUVINILCORANTE
Funções específicas do segmento de tintas.

### TOTTERCEIROS
Total de terceiros.

### CTOF / CTOI
Conversões de tipo (caractere para float/integer).

### DESCPROGRESSBASE / DESCPROGRESSPERC / DESCPROGRESSVALOR
Desconto progressivo (base, percentual, valor).

### DIASTRABPROXIMAREFERENCIA
Dias trabalhados até próxima referência.
