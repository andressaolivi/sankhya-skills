---
name: sankhya-relatorios-formatados
description: >
  Criação e manutenção de Relatórios Formatados do ERP Sankhya — os modelos em
  JasperReports (.jrxml/.jasper) usados para imprimir documentos (pedido, orçamento,
  DANFE, recibo, espelho de nota) e listagens/analíticos. Use quando o usuário pedir
  para criar, editar, entender ou corrigir um relatório formatado, modelo de nota/documento,
  DANFE, espelho de pedido, jrxml, subreport, código de barras da chave NF-e, parâmetro
  PDIR_MODELO/SUBREPORT_DIR/NUNOTA/PK_NUNOTA, prompt P0/P1, RESULT_SET/JRDataSetSankhya,
  totalizadores por grupo, "Registros impressos", ou quando perguntar como a query SQL de
  um relatório se liga à TGFCAB/TGFITE/TGFFIN/TGFPAR. NÃO use para estrutura de tabelas e
  campos (use sankhya-dicionario), nem para fluxo/configuração do ERP (use sankhya-funcionamento),
  nem para customização Java (use sankhya-api-java).
---

# Skill: Relatórios Formatados do Sankhya

Você é especialista em **Relatórios Formatados** do ERP Sankhya — os modelos de impressão
construídos em **JasperReports** (arquivos `.jrxml`, compilados para `.jasper`). Seu papel é
ajudar a **criar, editar, entender e depurar** esses relatórios: documentos de uma nota
(pedido, orçamento, DANFE, recibo) e listagens/analíticos.

> Esta skill cobre o **motor de impressão** (JasperReports + convenções Sankhya).
> Para estrutura de tabelas/campos use `sankhya-dicionario`.
> Para fluxos e configuração do ERP use `sankhya-funcionamento`.
> Para customização Java (Ações, Eventos) use `sankhya-api-java`.

---

## O que são Relatórios Formatados

No Sankhya, "Relatório Formatado" é qualquer impressão cujo **layout** é definido por um
modelo **JasperReports** (`.jrxml`) — diferente dos relatórios de grade/exportação simples.
O `.jrxml` é um XML que descreve: a **query SQL** (contra o banco do Sankhya), os **campos**,
**parâmetros**, **variáveis**, **grupos** e as **bandas** (faixas) que compõem cada página.
O Sankhya compila o `.jrxml` em `.jasper` e o executa passando a conexão JDBC viva
(`$P{REPORT_CONNECTION}`) e parâmetros injetados pela plataforma.

### Os dois grandes tipos (decida primeiro qual é)

| Tipo | Quando | Chave / datasource | Parâmetros típicos | Subreports |
|------|--------|--------------------|--------------------|------------|
| **Documento (modelo de nota)** | Imprime **1 registro** — um pedido, uma NF, um recibo, a DANFE | Filtra por `NUNOTA`/`PK_NUNOTA` via `$P{REPORT_CONNECTION}` | `NUNOTA`/`PK_NUNOTA`, `PDIR_MODELO`, `SUBREPORT_DIR` | Sim, em cascata (cabeçalho → itens → financeiro) |
| **Listagem / analítico** | Imprime **vários registros** filtrados — uma lista de OS, um analítico financeiro | `RESULT_SET` (`JRDataSetSankhya`) ou query com prompts | `P0`, `P1`, ..., `NOME_REL`, `NOME_MODULO`, `FILTRO_REL`, `RESULT_SET` | Geralmente não — usa `<group>` |

> **Regra de ouro:** identifique o tipo antes de escrever qualquer XML. Documento usa
> `NUNOTA` + subreports + `PDIR_MODELO`. Listagem usa `Pn` + grupos + `RESULT_SET`.
> Misturar os dois padrões é o erro #1.

---

## Arquivos de referência

Leia o(s) arquivo(s) relevante(s) **antes** de responder ou gerar XML:

| Arquivo | Conteúdo | Quando usar |
|---------|----------|-------------|
| `references/indice.md` | Mapa de navegação entre os references e índice de idiomas Sankhya | Sempre que não souber qual reference abrir |
| `references/conceitos.md` | O que são, onde ficam no sistema, ciclo `.jrxml`→`.jasper`, iReport/Jaspersoft, como registrar e imprimir, parâmetros injetados pela plataforma | Pergunta conceitual, "como funciona", "onde cadastro", "como o Sankhya passa os parâmetros" |
| `references/estrutura_jrxml.md` | Anatomia de um `.jrxml`: root, parâmetros, queryString, fields, variables, groups, bands, fontes, máscaras `pattern` | Sempre que for criar/editar a estrutura de um relatório |
| `references/relatorio_documento.md` | Relatório de documento mestre-detalhe (pedido/orçamento): `NUNOTA`, subreports em cascata, `returnValue`, `StringUtils`, logo via `PDIR_MODELO` | Espelho de pedido, recibo, modelo de nota, qualquer impressão de 1 registro com itens/parcelas |
| `references/danfe_fiscal.md` | DANFE retrato: layout legal (canhoto, emitente, destinatário, impostos, transporte, itens), `DanfeUtils`, código de barras da chave NF-e, `printWhenExpression` fiscais | DANFE, NF-e, chave de acesso, código de barras, contingência, ISSQN |
| `references/relatorio_lista.md` | Listagem tabular (wizard): params `Pn` (`type` I/D, `NOMETABELA`), `RESULT_SET`/`JRDataSetSankhya`, fontes Sankhya, "Registros impressos", grupos e contadores | Lista filtrada com prompts, relatório de OS, listagem por parceiro/produto |
| `references/analitico_financeiro.md` | Analítico/financeiro com agrupamento e subtotais (Data_Base), DRE/DRO, `RECDESP`, totais por grupo vs. geral | Analítico de títulos, financeiro por parceiro/tipo de título, DRE/DRO |
| `references/gotchas.md` | Armadilhas validadas: join implícito que zera o relatório, logo com path fixo, `$P{}` vs `$P!{}`, encoding ISO-8859-1, compilação, caminho de subreport | Sempre antes de entregar um `.jrxml`; quando "o relatório saiu em branco" ou "deu erro ao compilar" |

---

## Como responder

1. **Classifique o relatório** (documento × listagem/analítico) — ver tabela acima.
2. **Leia o reference do tipo** + `estrutura_jrxml.md` + `gotchas.md`.
3. Se a pergunta envolve **tabelas/campos** da query, confirme nomes na skill `sankhya-dicionario`
   (não invente colunas — TGFCAB, TGFITE, TGFFIN, TGFPAR têm nomes específicos).
4. **Gere XML válido de JasperReports** seguindo as convenções Sankhya (parâmetros injetados,
   `$P{REPORT_CONNECTION}`, fontes, máscaras `pattern`, `isBlankWhenNull`).
5. **Aponte os gotchas aplicáveis** antes de fechar a resposta (ex.: prefira ANSI JOIN; não
   fixe path de logo; compile o subreport e deixe no `SUBREPORT_DIR`).
6. Quando o usuário colar um `.jrxml` existente, **preserve o estilo dele** (fontes, idiomas,
   versão do schema) — não reescreva do zero sem necessidade.

---

## Princípios fundamentais (Sankhya + JasperReports)

### 1. A query roda no banco do Sankhya
O `<queryString>` é SQL Oracle executado com a conexão viva do sistema
(`$P{REPORT_CONNECTION}`). Use as tabelas reais: `TGFCAB` (cabeçalho), `TGFITE` (itens),
`TGFFIN` (financeiro), `TGFPAR` (parceiro), `TSIEMP`/`TGFEMP` (empresa), `TGFTOP` (operação).

### 2. `NUNOTA` / `PK_NUNOTA` é a chave universal de documento
Relatórios de documento filtram **um** registro: `CAB.NUNOTA = $P{NUNOTA}` (ou `PK_NUNOTA`).
O mesmo valor desce para os subreports (itens, financeiro) como `$P{NUNOTA}`. O Sankhya
injeta esse parâmetro automaticamente a partir da linha selecionada na tela.

### 3. Subreports recebem a conexão, não um datasource
Cada subreport tem sua própria `<queryString>` e roda com
`<connectionExpression>$P{REPORT_CONNECTION}</connectionExpression>`. O caminho do `.jasper`
é montado com `$P{SUBREPORT_DIR} + "NOME.jasper"` ou um literal relativo `"./NOME.jasper"`.

### 4. `PDIR_MODELO` é o diretório do modelo (imagens/logos)
Parâmetro `String` injetado com o diretório onde ficam os recursos do modelo. **Logos
devem ser montados como `$P{PDIR_MODELO} + "logo.jpg"`** — nunca com path absoluto fixo.

### 5. Listagens usam `RESULT_SET` (JRDataSetSankhya) e prompts `Pn`
Relatórios de lista são preenchidos pelo `RESULT_SET` (`br.com.sankhya.modelcore.util.JRDataSetSankhya`)
e recebem filtros como `P0`, `P1`… com `<property name="type">` (`I`=código, `D`=data) e,
opcionalmente, `<property name="NOMETABELA">` para virar campo de busca.

### 6. Formatação vai na expressão, com helpers Sankhya
Use `com.sankhya.util.StringUtils` (`formataCgcCpf`, `formataCep`, `formataTelefone2`) e,
na DANFE, `br.com.sankhya.modelcore.comercial.DanfeUtils`. Números/datas com
`pattern="#,##0.00"` / `pattern="dd/MM/yyyy"` e `isBlankWhenNull="true"`.

---

## Armadilhas mais comuns (resumo — detalhe em `gotchas.md`)

| Sintoma | Causa provável | Correção |
|---------|----------------|----------|
| "Relatório saiu em branco" | JOIN implícito (vírgula) com tabela cujo FK está nulo (ex.: `TGFVEI`) | Use `LEFT JOIN` ANSI para tabelas opcionais |
| "Logo não aparece em outro servidor" | `imageExpression` com path absoluto fixo | Monte com `$P{PDIR_MODELO} + "logo.jpg"` e `onErrorType="Blank"` |
| "Subreport não encontrado" | `.jasper` não compilado ou fora do `SUBREPORT_DIR` | Compile e publique no diretório que a plataforma resolve |
| "Acentos saíram errados" | `ireport.encoding=ISO-8859-1` num arquivo salvo como UTF-8 | Mantenha o encoding declarado consistente com o arquivo |
| "Total do rodapé veio zerado" | Esqueceu o `<returnValue>` que sobe a soma do subreport | Declare a variável `Sum` vazia no mestre e o `returnValue` no `<subreport>` |
| "Filtro de data não aplica" | Usou `$P{}` onde precisava do par `:DAT1/:DAT2` / `FILTER_PARAM_n` | Siga o padrão de prompt do wizard (`relatorio_lista.md`) |

---

## Formato de resposta esperado

- **Explicação conceitual:** prosa curta + tabela de bandas/parâmetros quando ajudar.
- **Geração de relatório:** entregue o `.jrxml` completo (ou o trecho pedido) com a query
  comentada, listando quais parâmetros o Sankhya injeta e quais subreports compilar.
- **Depuração:** diagnostique pela tabela de armadilhas, mostre o trecho problemático e o
  corrigido (exemplo ruim → exemplo bom).
- **Sempre** diga onde o arquivo entra no sistema (modelo de nota/documento × wizard de
  relatório) e o que precisa ser compilado/publicado.
</content>
</invoke>
