# Analítico Financeiro e DRE/DRO — agrupamento, subtotais e totais com sinal

Relatórios financeiros com **quebra e subtotalização** (analítico de títulos) e o
demonstrativo de resultado (DRE/DRO). Baseado nos arquivos reais "Data_Base" (títulos em
aberto até a data base) e `DRO_SANKHYA` (Demonstrativo de Resultado Operacional).

## A família "Data Base" — títulos em aberto até uma data de corte

Uma mesma consulta-base, em cinco variantes de layout:

| Arquivo | Quebra | Tem `<detail>`? | Subtotal | Total geral |
|---------|--------|-----------------|----------|-------------|
| AnalíticoR | nenhuma (lista plana) | sim | — | `$V{VLRDESDOB_3}` (summary) |
| Analítico ParceiroR | por `CODPARC` | sim | groupFooter "PARCIAL:" `$V{VLRDESDOB_2}` | `$V{VLRDESDOB_3}` |
| Analítico TipTitR | por `CODTIPTIT` (página nova) | sim | groupFooter "PARCIAL:" `$V{VLRDESDOB_4}` | `$V{VLRDESDOB_3}` |
| ParceiroR (resumo) | por `CODPARC` | **não** | total no header (deferido) `$V{VLRDESDOB_4}` | `$V{VLRDESDOB_3}` |
| Tipo de TítuloR (resumo) | por `CODTIPTIT` | **não** | total no header (deferido) `$V{VLRDESDOB_1}` | `$V{VLRDESDOB_2}` |

### Geometria e linguagem
```xml
<jasperReport name="Data base" language="groovy"
    pageWidth="595" pageHeight="842" columnWidth="555"
    leftMargin="20" rightMargin="20" topMargin="20" bottomMargin="20">
```
A4 retrato, `language="groovy"`.

### Parâmetros (três)
```xml
<parameter name="Data Base" class="java.sql.Timestamp">
  <parameterDescription><![CDATA[]]></parameterDescription>
</parameter>
<parameter name="PDIR_MODELO" class="java.lang.String" isForPrompting="false">
  <defaultValueExpression><![CDATA["./"]]></defaultValueExpression>
</parameter>
<parameter name="CODEMP" class="java.lang.String">
  <property name="nomeTabela" value="TSIEMP"/>
  <parameterDescription><![CDATA[Cód. Empresa]]></parameterDescription>
</parameter>
```
- **`Data Base`** (`Timestamp`) — **corte único** (não faixa). Referenciado como
  `$P{Data Base}` (atenção ao espaço no nome).
- **`CODEMP`** — filtro de empresa com **`<property name="nomeTabela" value="TSIEMP"/>`**:
  esse atributo faz o prompt virar um **seletor de registro** ligado à `TSIEMP`. É o idioma
  central dos filtros em Relatórios Formatados (equivale ao `NOMETABELA` das listagens).
- **`PDIR_MODELO`** — `isForPrompting="false"`, para o logo.

### Query: posição em aberto numa data histórica
Tabelas: `TGFFIN` (financeiro/títulos), `TGFTIT` (tipo de título — note: **`TGFTIT`**, não
`TGFTIPTIT`), `TGFPAR` (parceiro), `TSIEMP` (empresa). É um `UNION ALL` de dois SELECTs:

**Ramo 1 — títulos normais:**
```sql
AND FIN.DTNEG <= $P{Data Base}
AND (FIN.DHBAIXA IS NULL OR FIN.DHBAIXA > $P{Data Base})
AND FIN.RECDESP = 1          -- receitas (contas a RECEBER)
AND FIN.PROVISAO = 'N'       -- exclui provisão; só realizados
AND FIN.NURENEG IS NULL      -- título comum
```

**Ramo 2 — títulos renegociados (`NURENEG IS NOT NULL`):** resolve o status efetivo na data
base via função de banco:
```sql
AND FIN.RECDESP = (CASE WHEN Fc_Verifica_RenegR(FIN.NURENEG, FIN.RECDESP, FIN.DTNEG,
                          TO_DATE('01/01/1900','dd/mm/yyyy'), $P{Data Base}) = 1 THEN 1
                        ELSE (CASE WHEN Fc_Verifica_RenegR(...) = 2 THEN 0 END) END)
```

Semântica financeira a saber:
- **`RECDESP`** — `1` = receita (a receber), `2`/`-1` = despesa (a pagar). Esses relatórios
  são fixos em A/R (`RECDESP=1`; cabeçalho "CONTAS A RECEBER").
- **`PROVISAO='N'`** — exclui títulos provisionados; só os realizados.
- **`DHBAIXA`** — data/hora da baixa. **Aberto na data base** = `DHBAIXA IS NULL OR DHBAIXA >
  $P{Data Base}` (nunca baixado, ou baixado só depois do corte). Com `DTNEG <= Data Base`
  reconstrói a posição em aberto em qualquer data passada.
- **`NURENEG`** — número de renegociação; `IS NULL` = comum, `IS NOT NULL` = oriundo de
  renegociação (tratado à parte).
- **`Fc_Verifica_RenegR(...)`** — função de banco Sankhya que decide o status do título
  renegociado na data base (1 = conta como receber, 2 = excluir).

> **O `ORDER BY` precisa casar com a quebra** (Jasper agrupa dados pré-ordenados):
> - Analítico ParceiroR: `ORDER BY CODPARC, DTNEG, NUMNOTA, DESDOBRAMENTO`
> - Analítico TipTitR: `ORDER BY CODTIPTIT, DTNEG, NUMNOTA, DESDOBRAMENTO`
> - resumos: `ORDER BY CODPARC` / `ORDER BY CODTIPTIT`

Coluna de dinheiro somada em todo lugar: **`VLRDESDOB`** (valor do desdobramento/parcela),
classe `java.lang.Double` nesses relatórios.

---

## O padrão de agrupamento e subtotal (o coração do analítico)

### 1. Subtotal por grupo (com `<detail>`)
```xml
<group name="PARCEIRO" isReprintHeaderOnEachPage="true">
  <groupExpression><![CDATA[$F{CODPARC}]]></groupExpression>
  <groupHeader>
    <band height="12">
      <textField><reportElement x="0" y="0" width="350" height="12"/>
        <textFieldExpression><![CDATA[$F{CODPARC}+" - "+$F{RAZAOSOCIAL}]]></textFieldExpression></textField>
    </band>
  </groupHeader>
  <groupFooter>
    <band height="21">
      <staticText><reportElement x="380" y="4" width="60" height="12"/><text><![CDATA[PARCIAL:]]></text></staticText>
      <textField pattern="#,##0.00"><reportElement x="445" y="4" width="100" height="12"/>
        <textFieldExpression><![CDATA[$V{VLRDESDOB_2}]]></textFieldExpression></textField>
    </band>
  </groupFooter>
</group>
```
A variável de subtotal:
```xml
<variable name="VLRDESDOB_2" class="java.lang.Double" calculation="Sum"
          resetType="Group" resetGroup="PARCEIRO">
  <variableExpression><![CDATA[$F{VLRDESDOB}]]></variableExpression>
</variable>
```

### 2. Relatório-resumo (uma linha por grupo, **sem `<detail>`**)
Coloca o total **no header** do grupo, com avaliação deferida:
```xml
<group name="PARCEIRO" isReprintHeaderOnEachPage="true">
  <groupExpression><![CDATA[$F{CODPARC}]]></groupExpression>
  <groupHeader>
    <band height="15">
      <textField><reportElement x="0" y="0" width="60" height="12"/>
        <textFieldExpression><![CDATA[$F{CODPARC}]]></textFieldExpression></textField>
      <textField><reportElement x="65" y="0" width="350" height="12"/>
        <textFieldExpression><![CDATA[$F{RAZAOSOCIAL}]]></textFieldExpression></textField>
      <textField evaluationTime="Group" evaluationGroup="PARCEIRO" pattern="#,##0.00">
        <reportElement x="445" y="0" width="100" height="12"/>
        <textFieldExpression><![CDATA[$V{VLRDESDOB_4}]]></textFieldExpression></textField>
    </band>
  </groupHeader>
</group>
```
> **`evaluationTime="Group" evaluationGroup="PARCEIRO"`** é o idioma do resumo: adia o cálculo
> até o grupo inteiro ser lido, permitindo que um **header** exiba o total do grupo (sem isso,
> o header imprime antes das linhas serem somadas). É o que transforma o header em linha-resumo.

### 3. Total geral
`Sum` **sem `resetType`** (default = Report, acumula no relatório todo), exibido no `summary`:
```xml
<variable name="VLRDESDOB_3" class="java.lang.Double" calculation="Sum">
  <variableExpression><![CDATA[$F{VLRDESDOB}]]></variableExpression>
</variable>
```

### Resumo das regras
| Quero | Como |
|-------|------|
| Subtotal por grupo | `Sum` + `resetType="Group"` + `resetGroup` → `groupFooter` |
| Total geral | `Sum` sem `resetType` → `summary` |
| Total do grupo no header (resumo sem detalhe) | `textField` `evaluationTime="Group"` `evaluationGroup` |
| Cada grupo em página nova | `<group ... isStartNewPage="true">` |
| Repetir cabeçalho do grupo ao quebrar página | `isReprintHeaderOnEachPage="true"` |

> iReport costuma gerar **mais variáveis `VLRDESDOB_n` do que o relatório usa** (sobras). Não
> se assuste com `_1/_2/_3/_4` — só algumas são referenciadas nas bandas.

---

## DRE / DRO — Demonstrativo de Resultado com total com sinal

`DRO_SANKHYA` é um Demonstrativo de Resultado Operacional (primo do DRE): resultado líquido
do período, organizado em **Receitas** e **Despesas** por natureza.

### Diferenças de root e parâmetros
```xml
<jasperReport name="report1" language="groovy" pageWidth="595" pageHeight="842"
    columnWidth="555" leftMargin="20" rightMargin="20" topMargin="20" bottomMargin="20"
    isFloatColumnFooter="true">

<parameter name="P_DATAINI" class="java.sql.Timestamp"><parameterDescription><![CDATA[Período Inicial]]></parameterDescription></parameter>
<parameter name="P_DATAFIM" class="java.sql.Timestamp"><parameterDescription><![CDATA[Período Final]]></parameterDescription></parameter>
<parameter name="P_CODEMP" class="java.math.BigDecimal">
  <property name="nomeTabela" value="TGFEMP"/>
  <parameterDescription><![CDATA[Empresa]]></parameterDescription></parameter>
<parameter name="PDIR_MODELO" class="java.lang.String" isForPrompting="false"/>
```
- Convenção de prefixo **`P_`** e **faixa de datas** `P_DATAINI`/`P_DATAFIM` (não corte único).
- **`isFloatColumnFooter="true"`** — o total final flutua logo abaixo da última linha.

### Query agregada por natureza
Tabelas: `VGFFIN` (**view** do financeiro), `TGFNAT` (natureza/plano de contas), `TGFPAR`,
`TGFTIT`, `TGFEMP`, `TSIEMP`. Agrega com `SUM ... GROUP BY`:
```sql
SELECT SUM(FIN.VLRLIQUIDO) AS VLRLIQUIDO, SUM(FIN.VLRDESDOB) AS VLRDESDOB,
       FIN.CODNAT, GETDATE() AS EMISSAO, EMP.RAZAOSOCIAL, NAT.DESCRNAT AS DESCRICAO,
       CASE WHEN (FIN.NURENEG IS NULL OR FIN.NURENEG = 0) THEN FIN.RECDESP
            WHEN FIN.RECDESP <> 0 THEN 0
            WHEN FIN.NURENEG < 0 THEN -1 ELSE 1 END AS RECDESP
FROM VGFFIN FIN, TGFPAR PAR, TGFTIT TIT, TGFNAT NAT, TGFEMP E, TSIEMP EMP
WHERE FIN.CODNAT = NAT.CODNAT
  AND FIN.PROVISAO = 'N'
  AND FIN.DHBAIXA BETWEEN $P{P_DATAINI} AND $P{P_DATAFIM}
  AND EMP.CODEMP = $P{P_CODEMP}
GROUP BY FIN.CODNAT, EMP.RAZAOSOCIAL, NAT.DESCRNAT, CASE WHEN ... END
ORDER BY recdesp DESC, vlrdesdob DESC
```
- **`TGFNAT`** (natureza) é a dimensão organizadora — `CODNAT` + `DESCRNAT`.
- **Base por baixa:** `DHBAIXA BETWEEN P_DATAINI AND P_DATAFIM` → resultado **realizado** no
  período (diferente do snapshot em aberto da família Data Base).
- **`RECDESP` normalizado por `CASE`** para receita(+1)/despesa(0 ou −1), considerando
  renegociação — usado para agrupar e para dar sinal ao valor.
- `GETDATE()` indica **SQL Server** (a família Data Base usa Oracle `TO_DATE`).

### Grupo Receitas/Despesas e total com sinal
```xml
<group name="recdesp" keepTogether="true">
  <groupExpression><![CDATA[$F{RECDESP}]]></groupExpression>
  <groupHeader><band height="20">
    <textField><reportElement x="0" y="0" width="300" height="16"/>
      <textFieldExpression><![CDATA[$F{RECDESP}.intValue()==1 ? "Receitas" : "Despesas"]]></textFieldExpression></textField>
  </band></groupHeader>
  <groupFooter><band height="20">
    <staticText><text><![CDATA[Total:]]></text></staticText>
    <textField pattern="#,##0.00;-#,##0.00"><textFieldExpression><![CDATA[$V{recdesp}]]></textFieldExpression></textField>
  </band></groupFooter>
</group>
```
As variáveis:
```xml
<!-- subtotal da seção (Receitas / Despesas) -->
<variable name="recdesp" class="java.math.BigDecimal" resetType="Group" resetGroup="recdesp" calculation="Sum">
  <variableExpression><![CDATA[$F{VLRDESDOB}]]></variableExpression>
</variable>
<!-- RESULTADO OPERACIONAL = soma com sinal (receita +, despesa -) -->
<variable name="Geral" class="java.math.BigDecimal" calculation="Sum">
  <variableExpression><![CDATA[new java.math.BigDecimal( $F{VLRDESDOB}.doubleValue() * $F{RECDESP}.doubleValue() )]]></variableExpression>
</variable>
```
> O **total com sinal** é a aritmética do DRE: multiplicar `VLRDESDOB * RECDESP` (receita +1,
> despesa −1) faz um único acumulador (`Geral`) calcular o **resultado líquido**
> (receitas − despesas). Exibido na **`lastPageFooter`** ("Resultado Operacional:" `$V{Geral}`)
> com `isFloatColumnFooter="true"` para sentar logo abaixo da última linha.

### Bandas do DRO
| Banda | Conteúdo |
|-------|----------|
| `title` (h≈77) | Faixa verde (`backcolor="#009900"`, texto branco) "DEMONSTRATIVO DE RESULTADO OPERACIONAL", logo (`$P{PDIR_MODELO}+"logo.png"`), razão social, "Período:" P_DATAINI à P_DATAFIM |
| groupHeader/footer (Receitas/Despesas) | rótulo da seção / "Total:" `$V{recdesp}` |
| `detail` (h≈20) | descrição da natureza + valor com sinal |
| `lastPageFooter` (h≈22) | faixa verde "Resultado Operacional:" + `$V{Geral}` |

Organização: **natureza → seção receita/despesa → soma com sinal → resultado operacional**.
O `CODCENCUS` (centro de custo) aparece comentado — dica de que DREs costumam ganhar uma
segunda dimensão (centro de custo).

---

## Idiomas financeiros (resumo)

- **`nomeTabela`** no parâmetro → seletor de registro ligado à tabela (`TSIEMP`/`TGFEMP`).
- **Corte único (`Data Base`)** × **faixa (`P_DATAINI`/`P_DATAFIM`)** — dois idiomas válidos.
- **`Fc_Verifica_RenegR`** para títulos renegociados na data base.
- **Total com sinal** (`VLRDESDOB * RECDESP`) para resultado líquido num só acumulador.
- **`evaluationTime="Group"`** para total de grupo exibido no header (resumo sem detalhe).
- Máscaras: `#,##0.00` e a variante com sinal `#,##0.00;-#,##0.00` (negativo com `-`).
- **Sem scriptlets, sem zebra** nesses modelos — tudo com variáveis + SQL. (Para zebrar
  linhas: `printWhenExpression` na banda com `new Boolean($V{REPORT_COUNT}.intValue()%2==0)`.)
- Atenção ao **dialeto** do banco: Oracle (`TO_DATE`, `NVL`, `SYSDATE`) × SQL Server
  (`GETDATE()`, `ISNULL`).
- Confirme nomes de coluna/tabela na skill `sankhya-dicionario` (ex.: `TGFTIT` × `TGFTIPTIT`).
</content>
