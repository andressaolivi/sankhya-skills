# Índice — Relatórios Formatados do Sankhya

Mapa de navegação entre os references e dicionário rápido dos idiomas Sankhya.

## Qual reference abrir

| Sua pergunta / tarefa | Reference |
|-----------------------|-----------|
| "O que é Relatório Formatado?", "onde cadastro?", "como o Sankhya passa os parâmetros?", ciclo `.jrxml`→`.jasper` | `conceitos.md` |
| Montar/editar a estrutura de qualquer `.jrxml` (root, parâmetros, query, fields, variables, groups, bands, fontes, máscaras) | `estrutura_jrxml.md` |
| Espelho de pedido/orçamento, recibo, modelo de nota, impressão de 1 registro com itens/parcelas | `relatorio_documento.md` |
| DANFE, NF-e, chave de acesso, código de barras, contingência, ISSQN | `danfe_fiscal.md` |
| Lista filtrada com prompts, relatório de OS, listagem por parceiro/produto, `Pn`/`RESULT_SET` | `relatorio_lista.md` |
| Analítico de títulos, financeiro com quebra/subtotal, DRE/DRO, `RECDESP`, total com sinal | `analitico_financeiro.md` |
| "Saiu em branco", "erro ao compilar", revisar antes de entregar | `gotchas.md` |

## Decisão rápida: que tipo de relatório é?

```
Imprime UM registro (uma nota)?  ─ sim → documento → relatorio_documento.md
                                 │        └ é NF-e/DANFE? → danfe_fiscal.md
                                 └ não → imprime VÁRIOS registros filtrados?
                                          ├ lista tabular com prompts → relatorio_lista.md
                                          └ financeiro com quebra/subtotal/DRE → analitico_financeiro.md
```

## Dicionário de idiomas Sankhya (onde cada um é detalhado)

| Idioma | O que é | Reference |
|--------|---------|-----------|
| `NUNOTA` / `PK_NUNOTA` | Chave do documento, injetada pela plataforma | documento / danfe |
| `PDIR_MODELO` | Diretório do modelo (imagens/logos) | conceitos, documento, danfe |
| `SUBREPORT_DIR` | Diretório dos `.jasper` de subreport | conceitos, documento |
| `$P{REPORT_CONNECTION}` | Conexão JDBC viva, passada aos subreports | documento, danfe |
| `RESULT_SET` (`JRDataSetSankhya`) | Datasource das listagens | lista |
| `NOME_REL` / `NOME_MODULO` / `FILTRO_REL` | Título/módulo/filtros no cabeçalho de lista | lista |
| `Pn` + `type` (I/D) + `NOMETABELA` | Prompts do wizard (campo de busca) | lista |
| `nomeTabela` (property) | Seletor de registro no prompt financeiro | analitico |
| `returnValue` | Sobe somas do subreport ao mestre | documento |
| `evaluationTime="Group"` | Total de grupo exibido no header (resumo) | analitico |
| `RECDESP` (1/−1) | Receita/despesa em `TGFFIN` | analitico, gotchas |
| Total com sinal (`VLRDESDOB*RECDESP`) | Resultado líquido do DRE/DRO | analitico |
| `Fc_Verifica_RenegR` | Função de banco p/ título renegociado na data base | analitico |
| `com.sankhya.util.StringUtils` | Máscaras BR (CNPJ/CPF, CEP, telefone) | documento |
| `br.com.sankhya.modelcore.comercial.DanfeUtils` | Helpers fiscais da DANFE | danfe |
| `BcImage.getBarcodeImage(8,...)` | Code-128 da chave NF-e | danfe |

## Tabelas Sankhya mais usadas nas queries

| Tabela | Conteúdo | Aparece em |
|--------|----------|-----------|
| `TGFCAB` | Cabeçalho de nota (pedido/NF/orçamento) | documento, danfe |
| `TGFITE` | Itens da nota | documento, danfe |
| `TGFFIN` | Financeiro/títulos/parcelas | documento, analitico |
| `TGFPAR` | Parceiro (cliente/fornecedor) | todos |
| `TSIEMP` / `TGFEMP` | Empresa (cadastral / fiscal) | todos |
| `TGFPRO` | Produto/serviço | documento, danfe, lista |
| `TGFNAT` | Natureza (plano de contas) | analitico (DRE) |
| `TGFTIT` | Tipo de título (≠ TGFTIPTIT) | analitico |
| `TGFTOP` | Tipo de operação | danfe |
| `TGFCFO` | CFOP | danfe |
| `TGFVOA` | Volume alternativo (conversão de unidade) | documento |
| `TCSOSE` / `TCSITE` / `TCSERR` | OS / itens de OS / erros (Contratos e Serviços) | lista |
| `TSIUSU` | Usuário do sistema | lista |
| `TSIPAR` | Parâmetros do sistema | danfe |
| `VGFFIN` | View do financeiro | analitico (DRO) |

> Sempre confirme nomes/colunas na skill **`sankhya-dicionario`** antes de escrever a query.

## Modelos de exemplo analisados (origem desta skill)

| Conjunto | Tipo | Ensina |
|----------|------|--------|
| PEDIDO + ITENS_PEDIDO + FINAN_PEDIDO | Documento mestre-detalhe | subreports, `returnValue`, `StringUtils`, conversão de unidade |
| danfe_retrato + _sub + _itens | DANFE (fiscal) | layout legal, `DanfeUtils`, Code-128, `printWhenExpression` |
| relatorio-859..863 | Listagem (wizard) | `Pn`, `RESULT_SET`, grupos, "Registros impressos" |
| Data_Base (5 variantes) | Analítico financeiro | quebra/subtotal, resumo com `evaluationTime="Group"` |
| DRO_SANKHYA | DRE/DRO | seção Receitas/Despesas, total com sinal |
</content>
