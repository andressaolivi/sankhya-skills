# Relatório de Documento (mestre-detalhe) — Pedido, Orçamento, Recibo

Relatório que imprime **um único documento** (uma nota) com seu cabeçalho, itens e parcelas.
É o padrão do "espelho de pedido", recibo, ordem de serviço impressa, modelo de nota. Baseado
nos arquivos reais `PEDIDO`, `ITENS_PEDIDO`, `FINAN_PEDIDO`.

## Arquitetura

```
PEDIDO.jasper  (mestre — cabeçalho, parceiro, totais, observação)
  ├─ banda detail  → ITENS_PEDIDO.jasper   (subreport dos itens; devolve somas)
  └─ banda summary → FINAN_PEDIDO.jasper   (subreport das parcelas)
```

A chave que amarra tudo é **`NUNOTA`**: o mestre filtra `CAB.NUNOTA = $P{NUNOTA}` e passa o
mesmo valor para cada subreport.

---

## 1. O mestre

### Geometria e parâmetros
```xml
<jasperReport name="PEDIDO_DE_VENDA" pageWidth="842" pageHeight="590" orientation="Landscape"
    columnWidth="814" leftMargin="14" rightMargin="14" topMargin="20" bottomMargin="20">

  <import value="net.sf.jasperreports.engine.*"/>
  <import value="java.util.*"/>
  <import value="com.sankhya.util.StringUtils"/>

  <parameter name="PDIR_MODELO" class="java.lang.String">
    <defaultValueExpression><![CDATA["C://"]]></defaultValueExpression>
  </parameter>
  <parameter name="NUNOTA" class="java.math.BigDecimal"/>
  <parameter name="SUBREPORT_DIR" class="java.lang.String" isForPrompting="false">
    <defaultValueExpression><![CDATA["./"]]></defaultValueExpression>
  </parameter>
```

- **`NUNOTA`** — injetado pelo Sankhya a partir da linha selecionada na tela. É o
  **Número Único** interno de `TGFCAB` (não o `NUMNOTA` impresso). Sem `isForPrompting="false"`,
  pois pode ser solicitado se não vier.
- **`PDIR_MODELO`** — diretório do modelo (para logos).
- **`SUBREPORT_DIR`** — diretório dos `.jasper` de subreport (`isForPrompting="false"`).

### Query do cabeçalho
Puxa cabeçalho + parceiro + empresa + vendedor + endereço:
```sql
SELECT CAB.NUNOTA, CAB.NUMNOTA, CAB.OBSERVACAO, EMP.RAZAOSOCIAL AS RAZAOEMP,
       CAB.CODVEND, VEN.APELIDO, CAB.CODPARC, PAR.NOMEPARC, PAR.RAZAOSOCIAL,
       PAR.TELEFONE, PAR.CGC_CPF, PAR.CEP, PAR.INSCESTADNAUF,
       ENDE.NOMEEND, PAR.NUMEND, CID.NOMECID, UFS.UF, BAI.NOMEBAI,
       CAB.VLRNOTA, CAB.VLRDESCTOT
FROM TGFCAB CAB
INNER JOIN TGFPAR PAR ON PAR.CODPARC = CAB.CODPARC
LEFT  JOIN TSIEND ENDE ON ENDE.CODEND = PAR.CODEND
LEFT  JOIN TSICID CID  ON CID.CODCID  = PAR.CODCID
LEFT  JOIN TSIUFS UFS  ON UFS.CODUF   = CID.UF
LEFT  JOIN TSIBAI BAI  ON BAI.CODBAI  = PAR.CODBAI
LEFT  JOIN TSIEMP EMP  ON EMP.CODEMP  = CAB.CODEMP
LEFT  JOIN TGFVEN VEN  ON VEN.CODVEND = CAB.CODVEND
WHERE CAB.NUNOTA = $P{NUNOTA}
```

> ⚠️ O arquivo original usa **join por vírgula** e um `INNER` obrigatório com `TGFVEI`
> (veículo). Se a nota não tem veículo, o relatório **sai em branco**. Use `LEFT JOIN` para
> toda tabela opcional (veículo, vendedor, endereço). Ver `gotchas.md`.

### Tabelas (módulo comercial)
`TGFCAB` cabeçalho · `TGFITE` itens · `TGFFIN` financeiro · `TGFPAR` parceiro ·
`TSIEMP` empresa · `TGFVEN` vendedor · `TSIEND`/`TSICID`/`TSIUFS`/`TSIBAI` endereço.

### Formatação com helpers Sankhya
`com.sankhya.util.StringUtils` formata documentos brasileiros direto na expressão:
```xml
<textFieldExpression><![CDATA[StringUtils.formataCgcCpf($F{CGC_CPF})]]></textFieldExpression>  <!-- CNPJ/CPF -->
<textFieldExpression><![CDATA[StringUtils.formataCep($F{CEP})]]></textFieldExpression>          <!-- 00000-000 -->
<textFieldExpression><![CDATA[StringUtils.formataTelefone2($F{TELEFONE})]]></textFieldExpression>
```
Concatenação com null-guard:
```xml
<textFieldExpression><![CDATA[$F{CODPARC}+"-"+$F{NOMEPARC}
  + ($F{RAZAOSOCIAL}==null ? "" : " / "+$F{RAZAOSOCIAL})]]></textFieldExpression>
```

### Variáveis vazias que recebem o total do subreport
O mestre **não calcula** os totais — ele os recebe do subreport via `returnValue`:
```xml
<variable name="TOTAL_PRODUTO" class="java.math.BigDecimal" calculation="Sum"/>
<variable name="TOTAL_SERVICO" class="java.math.BigDecimal" calculation="Sum"/>
<variable name="DESCONTO_TOTAL" class="java.math.BigDecimal" calculation="Sum"/>
<variable name="VALOR_LIQUIDO" class="java.math.BigDecimal" calculation="Sum"/>
```
(Note: sem `<variableExpression>` — são preenchidas pelo retorno do subreport.)

---

## 2. Subreport de itens (`ITENS_PEDIDO`)

### Geometria de subreport
```xml
<jasperReport name="ITENS_PEDIDO_DE_VENDA" pageWidth="842" pageHeight="595"
    orientation="Landscape" columnWidth="842"
    leftMargin="0" rightMargin="0" topMargin="0" bottomMargin="0">
  <parameter name="NUNOTA" class="java.math.BigDecimal" isForPrompting="false"/>
```
**Margens zero** — o subreport é posicionado dentro do elemento do mestre. `NUNOTA` chega do
mestre, por isso `isForPrompting="false"`.

### Query dos itens (com conversão de unidade)
```sql
SELECT ITE.CODPROD, PRO.DESCRPROD, ITE.USOPROD,
  (CASE WHEN VOA.CODPROD IS NULL THEN ITE.QTDNEG
        WHEN VOA.DIVIDEMULTIPLICA='D' THEN ITE.QTDNEG*VOA.QUANTIDADE
        ELSE ITE.QTDNEG/VOA.QUANTIDADE END) AS QTDNEG,
  ITE.VLRUNIT, ITE.CODVOL, ITE.VLRDESC,
  ITE.QTDNEG*ITE.VLRUNIT AS TOTALITEM, ITE.VLRTOT-ITE.VLRDESC AS TOTLIQ,
  ITE.CODCFO AS CFOP, PRO.NCM, ITE.BASEICMS, ITE.ALIQICMS
FROM TGFITE ITE
INNER JOIN TGFPRO PRO ON ITE.CODPROD = PRO.CODPROD
LEFT  JOIN TGFVOA VOA ON VOA.CODPROD=ITE.CODPROD AND VOA.CODVOL=ITE.CODVOL
WHERE ITE.NUNOTA = $P{NUNOTA} AND ITE.SEQUENCIA > 0
ORDER BY ITE.CODPROD
```
- **`ITE.NUNOTA = $P{NUNOTA}`** — liga o subreport ao mestre.
- **`ITE.SEQUENCIA > 0`** — exclui a linha de sequência zero (agregadora/header interna).
- `TGFVOA` (volume alternativo) converte a unidade: `DIVIDEMULTIPLICA='D'` divide, senão
  multiplica, por `QUANTIDADE` (fator de conversão).

### Variáveis de soma (calculadas aqui, devolvidas ao mestre)
```xml
<variable name="TOTAL_PRODUTO" class="java.math.BigDecimal" calculation="Sum">
  <variableExpression><![CDATA[
    ($F{USOPROD}.toString().equalsIgnoreCase("S") ? new BigDecimal(0) : $F{TOTALITEM})
  ]]></variableExpression>
</variable>
<variable name="TOTAL_SERVICO" class="java.math.BigDecimal" calculation="Sum">
  <variableExpression><![CDATA[
    ($F{USOPROD}.toString().equalsIgnoreCase("S") ? $F{TOTALITEM} : new BigDecimal(0))
  ]]></variableExpression>
</variable>
```
A ternária separa produto de serviço pelo `USOPROD`; `new BigDecimal(0)` é o "zero" para as
linhas que não entram naquela soma.

---

## 3. Subreport financeiro (`FINAN_PEDIDO`)

```xml
<jasperReport name="FINAN_PEDIDO_DE_VENDA" ... leftMargin="0" rightMargin="0" ...>
  <parameter name="NUNOTA" class="java.math.BigDecimal" isForPrompting="false"/>
  <queryString><![CDATA[
    SELECT FIN.DESDOBRAMENTO, FIN.DTVENC, FIN.VLRDESDOB
    FROM TGFFIN FIN WHERE FIN.NUNOTA = $P{NUNOTA}
    ORDER BY FIN.DESDOBRAMENTO
  ]]></queryString>
```
`TGFFIN` = parcelas. `DESDOBRAMENTO` = nº da parcela, `DTVENC` = vencimento, `VLRDESDOB` = valor.

---

## 4. Como ligar os subreports no mestre

### Itens — na banda `<detail>` (devolvendo as somas)
```xml
<subreport isUsingCache="true">
  <reportElement key="ITENS" x="0" y="3" width="685" height="15"/>
  <subreportParameter name="NUNOTA">
    <subreportParameterExpression><![CDATA[$F{NUNOTA}]]></subreportParameterExpression>
  </subreportParameter>
  <connectionExpression><![CDATA[$P{REPORT_CONNECTION}]]></connectionExpression>
  <returnValue subreportVariable="TOTAL_PRODUTO" toVariable="TOTAL_PRODUTO" calculation="Sum"/>
  <returnValue subreportVariable="TOTAL_SERVICO" toVariable="TOTAL_SERVICO" calculation="Sum"/>
  <returnValue subreportVariable="DESCONTO_TOTAL" toVariable="DESCONTO_TOTAL" calculation="Sum"/>
  <returnValue subreportVariable="VALOR_LIQUIDO" toVariable="VALOR_LIQUIDO" calculation="Sum"/>
  <subreportExpression class="java.lang.String"><![CDATA[$P{SUBREPORT_DIR} + "ITENS_PEDIDO_DE_VENDA.jasper"]]></subreportExpression>
</subreport>
```

### Financeiro — na banda `<summary>`
```xml
<subreport isUsingCache="true">
  <reportElement key="FINAN" x="2" y="75" width="562" height="0" isRemoveLineWhenBlank="true"/>
  <subreportParameter name="NUNOTA">
    <subreportParameterExpression><![CDATA[$P{NUNOTA}]]></subreportParameterExpression>
  </subreportParameter>
  <connectionExpression><![CDATA[$P{REPORT_CONNECTION}]]></connectionExpression>
  <subreportExpression class="java.lang.String"><![CDATA[$P{SUBREPORT_DIR} + "FINAN_PEDIDO_DE_VENDA.jasper"]]></subreportExpression>
</subreport>
```

### Pontos-chave do wiring
| Elemento | O que faz |
|----------|-----------|
| `subreportExpression` | Monta o caminho do `.jasper`: `$P{SUBREPORT_DIR} + "NOME.jasper"`. O nome do `.jasper` deve casar com o `name` do subreport |
| `connectionExpression` = `$P{REPORT_CONNECTION}` | Passa a conexão JDBC viva — o subreport roda a **própria** query |
| `subreportParameter name="NUNOTA"` | Passa o `NUNOTA` para baixo (use `$F{NUNOTA}` do campo do mestre ou `$P{NUNOTA}` do parâmetro — ambos funcionam) |
| `returnValue` | **Sobe** a variável de soma do subreport para a variável homônima do mestre (`calculation="Sum"`) — é assim que os totais chegam ao `summary` |
| `isUsingCache="true"` | Cacheia o `.jasper` compilado |
| `height="0"` + `isRemoveLineWhenBlank="true"` | Elemento se estica ao conteúdo e some se vazio |

### Exibindo os totais no `summary`
```xml
<textField pattern="#,##0.00"><reportElement x="700" y="10" width="100" height="12"/>
  <textFieldExpression class="java.math.BigDecimal"><![CDATA[$V{TOTAL_PRODUTO}]]></textFieldExpression>
</textField>
```

---

## 5. Logo (forma correta)

```xml
<image onErrorType="Blank">
  <reportElement x="0" y="0" width="120" height="40"/>
  <imageExpression class="java.lang.String"><![CDATA[$P{PDIR_MODELO} + "logo.jpg"]]></imageExpression>
</image>
```
**Nunca** use path absoluto fixo (`"/home/mgeweb/repositorio/logos/logo.jpg"`) — quebra ao
trocar de servidor. Monte sempre com `$P{PDIR_MODELO}` e `onErrorType="Blank"`.

---

## Receita de bolo (criar um documento mestre-detalhe)

1. Mestre A4 com `NUNOTA`, `PDIR_MODELO`, `SUBREPORT_DIR`; query do cabeçalho filtrada por
   `CAB.NUNOTA = $P{NUNOTA}` (use LEFT JOIN para tabelas opcionais).
2. Para cada bloco de detalhe (itens, parcelas, impostos) crie um subreport com margem 0,
   parâmetro `NUNOTA` (`isForPrompting="false"`) e query filtrada por `NUNOTA`.
3. No subreport de itens, declare as variáveis `Sum` que o mestre vai exibir.
4. No mestre, declare as mesmas variáveis **vazias** (`calculation="Sum"`, sem expressão).
5. Embuta os subreports nas bandas certas (`detail`/`summary`), passando
   `$P{REPORT_CONNECTION}`, o `NUNOTA`, montando o path com `$P{SUBREPORT_DIR}` e usando
   `returnValue` para subir os totais.
6. Compile todos os `.jrxml` (mestre + subreports) em `.jasper` e publique no diretório que o
   `SUBREPORT_DIR` resolve.
7. Cadastre o modelo na tela de **Modelo de Impressão de Nota** e vincule à TOP/botão.
</content>
