# DANFE — Documento Auxiliar da Nota Fiscal Eletrônica (retrato)

A DANFE é um documento de layout **legalmente regulado** (Ajuste SINIEF / Manual de
Integração do Contribuinte). É um relatório de documento mestre-detalhe especial — mais
complexo que o pedido por causa das seções fiscais obrigatórias e do código de barras da
chave. Baseado nos arquivos reais `danfe_retrato`, `danfe_retrato_sub`, `danfe_retrato_itens`.

## Arquitetura (3 níveis)

```
danfe_retrato.jasper        (mestre — canhoto/recibo + ISSQN + dados adicionais)
  └─ summary → danfe_retrato_sub.jasper       (corpo legal: emitente, destinatário,
        │                                       impostos, transporte, fatura, código de barras)
        └─ detail → danfe_retrato_itens.jasper (grade de produtos; repete por página)
```

> Idioma importante: a **query do mestre devolve uma única linha** (o cabeçalho da NF). O
> layout legal de fato fica no **sub**, chamado da banda `<summary>` do mestre. Assim o
> canhoto (recibo destacável) e a área "reservado ao fisco / dados adicionais" ficam no
> relatório externo, e o corpo formatado entra via subreport.

---

## 1. Geometria

```xml
<!-- mestre -->
<jasperReport name="danfe_retrato" pageWidth="595" pageHeight="842"
    columnWidth="567" leftMargin="14" rightMargin="14" topMargin="22" bottomMargin="22"
    whenResourceMissingType="Empty">
<!-- sub e itens -->
<jasperReport name="danfe_retrato_sub" pageWidth="551" pageHeight="800"
    columnWidth="551" leftMargin="0" rightMargin="0" topMargin="0" bottomMargin="0">
```
A4 retrato. Sub/itens com **largura 551** (= largura útil do mestre) e **margem zero**.
`whenResourceMissingType="Empty"` → logo ausente não quebra a impressão.

---

## 2. Parâmetros (note: `PK_NUNOTA`, não `NUNOTA`)

| Parâmetro | Classe | Onde | Para que |
|-----------|--------|------|----------|
| `PK_NUNOTA` | `BigDecimal` | todos | Chave da nota (injetada). Roteia todo o conjunto |
| `IMPITENSNFE` | `BigDecimal` | todos | Flag 0/1 do modo de desmembramento de itens da NF-e |
| `PDIR_MODELO` | `String` | sub | Diretório do modelo, prefixado às imagens (logo) |
| `LOGODIR` | `String` | mestre | Diretório do logo |
| `ORDITENS` | `String` | itens | Injetado em `ORDER BY $P{ORDITENS}` |
| `$P{REPORT_CONNECTION}` | `Connection` | todos | Conexão viva; subreports e `new DanfeUtils(...)` |

> Em DANFE a chave chama-se **`PK_NUNOTA`** (não `NUNOTA` como no pedido). Atenção ao nome.

---

## 3. Query — tabelas fiscais

Tudo parte de **`TGFCAB`** filtrado por `$P{PK_NUNOTA}`. Tabelas envolvidas:

| Tabela | Papel |
|--------|-------|
| `TGFCAB` | Cabeçalho: NUNOTA, NUMNOTA, SERIENOTA, **CHAVENFE**, **NUMPROTOC**, STATUSNFE, TPEMISNFE, totais, frete |
| `TGFITE` | Itens: qtde, valores, base/valor ICMS e IPI, CFOP, CST |
| `TGFPAR` | Parceiro (destinatário **e** transportador) |
| `TGFTOP` | Tipo de operação (ATUALLIVFIS, NFESEMDTENTSAI, GERAGNRE) |
| `TGFTPV` | Tipo de venda (gera texto de fatura/duplicata) |
| `TGFEMP` / `TSIEMP` | Empresa fiscal/cadastral (razão, CNPJ, IE, **LOGODANFE**, SIMPLES) |
| `TGFPRO` | Produto (descrição, NCM, casas decimais, peso) |
| `TGFCFO` | Descrição do CFOP |
| `TGFVEI`/`TGFORD` | Veículo / ordem de carga (placa, ANTT, UF) |
| `TGFVAR` | Desmembramento de itens (sub-filtro EXISTS) |
| `TSIPAR` | **Parâmetros do sistema** (`WHERE CHAVE='...' AND CODUSU=0`) |
| `TSIEND/TSIBAI/TSICID/TSIUFS/TSIREG/TSIIUF` | Normalização de endereço, CODIBGE, IE-ST |

### Chave de acesso e protocolo
```sql
CAB.CHAVENFE   -- 44 dígitos (código de barras e texto formatado)
CAB.NUMPROTOC  -- protocolo de autorização de uso
CAB.STATUSNFE, CAB.TPEMISNFE  -- status e tipo de emissão (2 = contingência)
```
Rótulo/valor alternam por `TPEMISNFE`:
```sql
CASE WHEN TPEMISNFE = 2 THEN 'DADOS DA NF-e'
     ELSE 'PROTOCOLO DE AUTORIZACAO DE USO' END
```

### Idiomas de SQL fiscais
- **Parâmetros do sistema como subselects:**
  ```sql
  (SELECT INTEIRO FROM TSIPAR WHERE CHAVE='RAZEMITENTDANFE') EMIT,
  (SELECT INTEIRO FROM TSIPAR WHERE CHAVE='RAZDESTINADANFE') DEST
  ```
  Chaves usadas: `RAZEMITENTDANFE`, `RAZDESTINADANFE`, `UNIPACITEDANFE`, `IMPHRSAIDADANFE`,
  `HAUNI`, `TOPNFEINTEGR`. Convenção `CODUSU=0` = default do sistema.
- **Funções de banco Sankhya:** `Danfe_Buildrazaosocial(flag, razao, fantasia)` (escolhe
  razão social × fantasia), `FC_OBS_PADRAO($P{PK_NUNOTA})` (observação padrão).
- **Transferência entre empresas:** `CASE WHEN CAB.TIPMOV='T' AND CAB.CODPARC=0 AND
  CAB.CODEMPNEGOC<>0 THEN <empresa> ELSE <parceiro>` — em transferência o "destinatário" é
  outra empresa, não um parceiro. Aparece em cada campo do destinatário.
- **Simples Nacional:** zera colunas de ICMS (`CASE WHEN EMP.SIMPLES='S' THEN 0 ELSE
  ITE.VLRICMS`) e força CST 41.
- **Desmembramento (flag `IMPITENSNFE`):**
  ```sql
  ( $P{IMPITENSNFE}=0 AND ITE.USOPROD<>'D' ) OR
  ( $P{IMPITENSNFE}=1 AND NOT EXISTS (SELECT 1 FROM TGFVAR VAR
        WHERE VAR.NUNOTA=ITE.NUNOTA AND VAR.NUNOTAORIG=ITE.NUNOTA
          AND VAR.SEQUENCIAORIG=ITE.SEQUENCIA) )
  ```

---

## 4. Helper `DanfeUtils`

```xml
<import value="br.com.sankhya.modelcore.comercial.DanfeUtils"/>
<import value="com.sankhya.util.StringUtils"/>
<import value="com.sankhya.util.StringFormat"/>
```

`br.com.sankhya.modelcore.comercial.DanfeUtils` é o utilitário central — usado de forma
**estática** e como **instância** (recebe a conexão para rodar queries próprias).

| Chamada | Uso |
|---------|-----|
| `DanfeUtils.getExtenso(valor)` | Valor por extenso (canhoto) |
| `DanfeUtils.getCurrency(valor)` | Moeda |
| `DanfeUtils.formatCgcCpf/formatCEP/formatTelefone(...)` | Máscaras BR |
| `DanfeUtils.formatNumeroNota(...)` | Nº da nota formatado |
| `DanfeUtils.formatValor(valor, casas)` / `formatValorFrete(valor, tipFrete)` | Valores |
| `DanfeUtils.getChaveNfe(chave, tpEmis, status)` | Chave de acesso formatada |
| `DanfeUtils.getChaveContigencia(codIbge, cgc, vlrNota, baseIcms, baseSubst, dtNeg, masc)` | Chave de contingência |
| `DanfeUtils.removeSinalMaiorMenor(s)` | Remove `<`/`>` |
| `new DanfeUtils(conn).getDescricaoItem(NUNOTA, SEQ)` | Descrição completa do item (por linha) |
| `new DanfeUtils(conn).formatQuantidade(qtd, casas)` / `.formataQtdeTransp(qtd)` | Quantidades |
| `new DanfeUtils(conn).getFaturas(NUNOTA, descrTipVenda, CODEMP)` | Bloco de fatura/duplicatas |

Também `StringUtils.stringZero(valor, n)` (zero-padding de CST), `getNullAsEmpty`.

---

## 5. Bandas → seções legais da DANFE

### Mestre `danfe_retrato`
| Banda | Conteúdo |
|-------|----------|
| `background` (h≈534) | Marca d'água "DANFE em contingência" (só se `TPEMISNFE==2`) |
| `title` (h≈41) | **CANHOTO/RECIBO** — "RECEBEMOS DE...", data de recebimento, assinatura, NF-e Nº/SÉRIE à direita, linha pontilhada de destaque |
| `pageFooter` (h≈116, só pág.1) | **CÁLCULO DO ISSQN** (se `VLRTOTSERV>0`) + **DADOS ADICIONAIS / INFORMAÇÕES COMPLEMENTARES** (`OBSERVACAO`) + **RESERVADO AO FISCO** |
| `summary` (h≈23) | Hospeda o subreport `danfe_retrato_sub` |

### Sub `danfe_retrato_sub`
| Banda | Conteúdo |
|-------|----------|
| `pageHeader` (h≈135) | Logo, **identificação do emitente**, caixa central "DANFE / Documento Auxiliar...", indicador 1-SAÍDA/2-ENTRADA, Nº/SÉRIE, FOLHA n/, **CHAVE DE ACESSO** formatada + **código de barras Code-128**, NATUREZA DA OPERAÇÃO, IE/CNPJ, **PROTOCOLO**, aviso vermelho "SEM VALOR FISCAL" |
| group `PrimeiraPagina` header (h≈187, `groupExpression=Boolean.TRUE`) | **DESTINATÁRIO/REMETENTE**, **FATURA/DUPLICATA** (`getFaturas`), **CÁLCULO DO IMPOSTO** (base/valor ICMS, ICMS ST, frete, seguro, desconto, IPI, **VALOR TOTAL DA NOTA**), **TRANSPORTADOR/VOLUMES** |
| `detail` (h≈20) | Hospeda o subreport `danfe_retrato_itens` (grade de produtos) |

### Itens `danfe_retrato_itens`
| Banda | Conteúdo |
|-------|----------|
| `columnHeader` (h≈21) | **DADOS DOS PRODUTOS/SERVIÇOS** — CÓDIGO, DESCRIÇÃO, NCM/SH, CST, CFOP, UN, QUANT, V.UNIT, V.DESC, %DESC, V.TOTAL, BC ICMS, V.ICMS, V.IPI, ALÍQ ICMS/IPI |
| `detail` (h≈12) | Uma linha por item; toda célula `isStretchWithOverflow`/`stretchType="RelativeToTallestObject"`/`isPrintWhenDetailOverflows` para descrições multi-linha não quebrarem a grade |

> O grupo `PrimeiraPagina` com `groupExpression=Boolean.TRUE` imprime o bloco
> destinatário/impostos/transporte **uma vez no topo**, enquanto o `pageHeader` (emitente +
> chave + barras) **reimprime em toda página**. `FOLHA $V{PAGE_NUMBER}/` faz "folha n de m".

---

## 6. Código de barras da chave de acesso (Code-128)

Desenhado no `pageHeader` do sub como um `<image>` cujo `imageExpression` chama o gerador de
barcode do iReport:

```xml
<image scaleImage="FillFrame" hAlign="Center" vAlign="Middle" evaluationTime="Report">
  <reportElement key="barcode-1" mode="Opaque" x="326" y="3" width="217" height="30"
                 forecolor="#000000" backcolor="#FFFFFF"/>
  <graphicElement fill="Solid"/>
  <imageExpression class="java.awt.Image"><![CDATA[
    it.businesslogic.ireport.barcode.BcImage.getBarcodeImage(8, $F{CHAVENFE}, false, false, null, 3, 180)
  ]]></imageExpression>
</image>
```
- `getBarcodeImage(tipo=8, codigo, checkSum, showText, font, barWidth, height)` — **tipo 8 =
  Code 128** na fábrica de barcode do iReport. Retorna `java.awt.Image`.
- `$F{CHAVENFE}` = chave de 44 dígitos; `showText=false` (o texto formatado é impresso à parte).
- `evaluationTime="Report"` para resolver tarde.

A chave legível acima do código:
```xml
<textField pattern="##.##.##.##.##.###.###/####-##-###.###.###-###-###.###.###-#">
  <textFieldExpression><![CDATA[DanfeUtils.getChaveNfe($F{CHAVENFE},$F{TPEMISNFE},$F{STATUSNFE})]]></textFieldExpression>
</textField>
```

> **DANFE de NF-e (modelo 55) usa apenas o código de barras Code-128C da chave — NÃO tem QR
> Code.** O QR Code é exclusivo da **NFC-e (modelo 65)**, que tem layout próprio (DANFE NFC-e).

---

## 7. `printWhenExpression` fiscais (mostrar/ocultar conforme a lei)

| Seção | Condição |
|-------|----------|
| Marca d'água contingência | `Boolean.valueOf($F{TPEMISNFE}.intValue()==2)` |
| Aviso "SEM VALOR FISCAL" | `Boolean.valueOf($F{TPEMISNFE}==null || $F{TPEMISNFE}.intValue()!=2)` |
| ISSQN / dados adicionais só pág.1 | `new Boolean($V{PAGE_NUMBER}.intValue()==1)` |
| Endereço do transportador só se existir | `new Boolean($F{CODPARCTRANSP}!=null && $F{CODPARCTRANSP}.intValue()>0)` |
| Quantidade só se positiva | `new Boolean($F{TRANSQTDE}.intValue()>0)` |

---

## 8. Logo da DANFE

```xml
<image onErrorType="Blank">
  <imageExpression class="java.lang.String"><![CDATA[$P{PDIR_MODELO} + "Logo/prestservicos.jpg"]]></imageExpression>
</image>
```
A query também seleciona `TSIEMP.LOGODANFE` / `TGFEMP.LOGODANFE` como fonte do logo por
empresa — o caminho dinâmico é montado a partir desse campo + `$P{PDIR_MODELO}`.

---

## 9. Subreports da DANFE (path relativo)

```xml
<subreport isUsingCache="true">
  <reportElement key="danfe_retrato_sub" positionType="Float" .../>
  <subreportParameter name="PK_NUNOTA"><subreportParameterExpression><![CDATA[$P{PK_NUNOTA}]]></subreportParameterExpression></subreportParameter>
  <subreportParameter name="IMPITENSNFE"><subreportParameterExpression><![CDATA[$P{IMPITENSNFE}]]></subreportParameterExpression></subreportParameter>
  <subreportParameter name="LOGODIR"><subreportParameterExpression><![CDATA[$P{LOGODIR}]]></subreportParameterExpression></subreportParameter>
  <connectionExpression><![CDATA[$P{REPORT_CONNECTION}]]></connectionExpression>
  <subreportExpression class="java.lang.String"><![CDATA["./danfe_retrato_sub.jasper"]]></subreportExpression>
</subreport>
```
- Caminho **literal relativo** `"./nome.jasper"` (a DANFE não usa `SUBREPORT_DIR` para path —
  `PDIR_MODELO`/`LOGODIR` são só para imagens).
- `PK_NUNOTA` + `IMPITENSNFE` descem mestre → sub → itens, para os três consultarem a mesma
  nota no mesmo modo.
- `positionType="Float"` deixa o corpo descer abaixo do canhoto de altura variável.

---

## Avisos ao criar/editar DANFE

- A DANFE tem **layout legal** — não invente posições. Use o modelo padrão do Sankhya como
  base e só altere o necessário (logo, observação, dados adicionais).
- Comportamento é dirigido por **parâmetros do sistema** (`TSIPAR`) e flags de **TOP/EMP**
  (`ATUALLIVFIS`, `NFESEMDTENTSAI`, `GERAGNRE`, `SIMPLES`, `VLRLIQITEMNFE`). Trate-os como a
  superfície de configuração.
- Padronize a formatação em `DanfeUtils` + expressões inline (não em variáveis).
- Code-128 da chave; **sem QR** para modelo 55.
</content>
