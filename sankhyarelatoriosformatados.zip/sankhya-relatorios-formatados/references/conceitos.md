# Conceitos — Relatórios Formatados do Sankhya

## O que é

"Relatório Formatado" é o nome que o Sankhya dá a qualquer impressão cujo **layout** é
definido por um modelo **JasperReports**. O modelo é um arquivo XML `.jrxml` (fonte),
compilado para `.jasper` (binário) e executado pelo motor do Sankhya. É o mecanismo usado
para:

- **Documentos de uma nota:** espelho de pedido/orçamento, recibo, DANFE, DANFE simplificada,
  romaneio, etiqueta, boleto, ordem de serviço impressa.
- **Listagens e analíticos:** lista de OS, analítico de títulos, posição de estoque,
  DRE/DRO, comissões, qualquer relatório tabular com filtros.

> JasperReports é a mesma tecnologia usada por iReport/Jaspersoft Studio. O Sankhya
> incorpora o engine e adiciona convenções próprias (parâmetros injetados, datasource,
> fontes empacotadas, helpers Java). **Quem sabe JasperReports já sabe 80% — os 20%
> restantes são as convenções Sankhya cobertas nesta skill.**

---

## Onde ficam no sistema

Há dois caminhos, conforme o tipo:

### 1. Modelo de Nota / Documento (relatório de documento)
Cadastrado em **Configurações → Modelo de Impressão de Nota** (ou via a tela de cadastro de
modelos de documento). O modelo é vinculado a um **TIPMOV/TOP** ou chamado pelo botão de
impressão da nota. Ao imprimir a partir de uma linha selecionada, o Sankhya injeta o
`NUNOTA`/`PK_NUNOTA` daquela linha e roda o `.jasper`.

### 2. Relatório Formatado / Wizard (listagem)
Cadastrado no **Construtor / Cadastro de Relatórios** (Relatórios Formatados). O usuário
desenha a consulta e os filtros (prompts), e o Sankhya gera um modelo a partir do template
`landscape_template`/`portrait_template`. Esses relatórios são preenchidos por um
**`RESULT_SET`** (não pela conexão direta) e exibem os prompts `P0`, `P1`… na hora de rodar.

> A diferença prática: documento = impressão amarrada a um registro; listagem = consulta
> com filtros que o usuário preenche. Veja `relatorio_documento.md` e `relatorio_lista.md`.

---

## Ciclo de vida: `.jrxml` → `.jasper`

1. **Autoria** — o `.jrxml` é desenhado no **iReport** (legado, o que o Sankhya
   historicamente usa — note as propriedades `ireport.*` nos arquivos) ou no
   **Jaspersoft Studio** (sucessor). Também pode ser editado como XML puro.
2. **Compilação** — o Sankhya compila o `.jrxml` em `.jasper`. A propriedade
   `sankhyaw.usejdtcompiler=true` faz o SankhyaW usar o compilador Eclipse JDT embutido para
   as expressões. Subreports precisam estar **compilados** (`.jasper`) e publicados no
   diretório que `SUBREPORT_DIR` resolve.
3. **Execução** — o engine recebe a conexão JDBC viva (`$P{REPORT_CONNECTION}`), injeta os
   parâmetros da plataforma (`NUNOTA`/`PK_NUNOTA`, `PDIR_MODELO`, `SUBREPORT_DIR`,
   `RESULT_SET`, `NOME_REL`, etc.), roda a `<queryString>` e monta as páginas banda a banda.
4. **Saída** — PDF (padrão), e também HTML/XLS conforme o ponto de chamada.

---

## Parâmetros injetados pela plataforma (você não preenche, o Sankhya preenche)

Esses parâmetros aparecem declarados no `.jrxml` mas têm `isForPrompting="false"` (ou são
preenchidos pelo engine). **Declarar é obrigatório; preencher é responsabilidade do Sankhya.**

| Parâmetro | Classe | Para que serve |
|-----------|--------|----------------|
| `$P{REPORT_CONNECTION}` | `java.sql.Connection` | Conexão JDBC viva. Passada aos subreports via `connectionExpression`. Built-in do Jasper, fornecida pelo Sankhya |
| `NUNOTA` **ou** `PK_NUNOTA` | `java.math.BigDecimal` | Chave do documento (cabeçalho da nota). Injetada a partir da linha selecionada. Desce para subreports |
| `PDIR_MODELO` | `java.lang.String` | Diretório do modelo no servidor — base para montar caminhos de **imagens/logos** (`$P{PDIR_MODELO}+"logo.jpg"`) |
| `SUBREPORT_DIR` | `java.lang.String` | Diretório dos `.jasper` de **subreport**. Caminho montado como `$P{SUBREPORT_DIR}+"NOME.jasper"`. `isForPrompting="false"` |
| `RESULT_SET` | `br.com.sankhya.modelcore.util.JRDataSetSankhya` | Datasource das **listagens** (wizard). O engine preenche o relatório a partir dele |
| `NOME_REL` | `java.lang.String` | Título do relatório exibido no cabeçalho (listagens) |
| `NOME_MODULO` | `java.lang.String` | Nome do módulo exibido no cabeçalho (ex.: "SankhyaW - Contratos e Serviços") |
| `FILTRO_REL` | `java.lang.String` | Texto com os filtros aplicados, ecoado no cabeçalho |
| `OUTPUT_STREAM`, `JASPER_PRINT` | `java.lang.String` | Infra interna do SankhyaW (saída) |
| `IMPITENSNFE` | `java.math.BigDecimal` | Flag 0/1 da DANFE (modo de desmembramento de itens) |
| `LOGODIR`, `ORDITENS` | `java.lang.String` | DANFE: diretório do logo / ordenação dos itens |

> **Regra:** nunca tente "passar" esses valores manualmente. Apenas **declare** o parâmetro
> com o nome e classe corretos e **referencie** com `$P{...}`. O engine resolve.

---

## Parâmetros de prompt (esses sim o usuário preenche)

São os filtros que o usuário informa ao rodar o relatório. Convenções:

- **Documento:** raramente tem prompt — recebe `NUNOTA` automaticamente.
- **Listagem (wizard):** prompts nomeados `P0`, `P1`, `P2`… (sequenciais), cada um com
  `<parameterDescription>` (rótulo) e `<property name="type">` (`I`=inteiro/código,
  `D`=data). Opcionalmente `<property name="NOMETABELA">`/`nomeTabela` vira um campo de
  busca ligado àquela tabela. Detalhe em `relatorio_lista.md`.
- **Analítico/financeiro próprio:** convenção `P_DATAINI`/`P_DATAFIM`/`P_CODEMP` (prefixo
  `P_`) ou um único `Data Base` de corte. Detalhe em `analitico_financeiro.md`.

---

## Datasource: conexão direta × RESULT_SET

| | Documento | Listagem (wizard) |
|---|-----------|-------------------|
| Datasource | `$P{REPORT_CONNECTION}` (JDBC) — cada relatório/subreport roda sua própria `<queryString>` | `RESULT_SET` (`JRDataSetSankhya`) preenche os campos |
| `<queryString>` | É executada de fato contra o banco | Existe para o wizard resolver filtro e metadados dos campos |
| Subreports | Sim, recebem a conexão | Geralmente não |

---

## Linguagem de expressão

- Documentos clássicos: expressões Java (imports `net.sf.jasperreports.engine.*`,
  `java.util.*`, `com.sankhya.util.StringUtils`).
- "Data base"/financeiros: `language="groovy"` (padrão do iReport Sankhya).
- Ambas funcionam; mantenha a linguagem declarada no root (`language="groovy"`) consistente
  com a sintaxe das expressões.

---

## Banco: Oracle vs SQL Server

O Sankhya roda sobre **Oracle** ou **SQL Server**. Isso afeta a `<queryString>`:

- Oracle: `TO_DATE('01/01/1900','dd/mm/yyyy')`, `NVL`, `SYSDATE`, joins por vírgula comuns.
- SQL Server: `GETDATE()`, `ISNULL`, `CONVERT`.

Sempre confirme o banco do cliente antes de usar funções específicas. Quando possível,
prefira SQL portável (ANSI JOIN, `CASE`, `COALESCE`).
</content>
