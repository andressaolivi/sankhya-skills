# Relatório de Listagem (wizard tabular) — listas filtradas

Relatório que imprime **vários registros** filtrados por prompts que o usuário preenche. É o
padrão do "Relatório Formatado" gerado pelo wizard do SankhyaW (templates
`landscape_template`/`portrait_template`). Baseado nos arquivos reais `relatorio-859` a `863`
(módulo Contratos e Serviços). Difere do relatório de documento: usa `RESULT_SET`, prompts
`Pn` e `<group>` (em vez de `NUNOTA` + subreports).

## Esqueleto

```xml
<jasperReport name="landscape_template" pageWidth="842" pageHeight="595" orientation="Landscape"
    columnWidth="814" leftMargin="14" rightMargin="14" topMargin="20" bottomMargin="20">

  <property name="ireport.encoding" value="ISO-8859-1"/>
  <property name="sankhyaw.usejdtcompiler" value="true"/>

  <import value="net.sf.jasperreports.engine.*"/>
  <import value="java.util.*"/>
  <import value="net.sf.jasperreports.engine.data.*"/>

  <!-- parâmetros de infraestrutura (sempre presentes) -->
  <parameter name="OUTPUT_STREAM" class="java.lang.String" isForPrompting="false"/>
  <parameter name="JASPER_PRINT"  class="java.lang.String" isForPrompting="false"/>
  <parameter name="NOME_REL"      class="java.lang.String" isForPrompting="false">
    <defaultValueExpression><![CDATA["Erros e Soluções"]]></defaultValueExpression></parameter>
  <parameter name="NOME_MODULO"   class="java.lang.String" isForPrompting="false">
    <defaultValueExpression><![CDATA["SankhyaW - Contratos e Serviços"]]></defaultValueExpression></parameter>
  <parameter name="FILTRO_REL"    class="java.lang.String" isForPrompting="false"/>
  <parameter name="RESULT_SET" class="br.com.sankhya.modelcore.util.JRDataSetSankhya" isForPrompting="false"/>

  <!-- prompt do usuário -->
  <parameter name="P0" class="java.math.BigDecimal">
    <property name="type" value="I"/>
    <property name="NOMETABELA" value="TGFPRO"/>
    <parameterDescription><![CDATA[Cód. Produto =]]></parameterDescription>
  </parameter>
  <parameter name="FILTER_PARAM_0" class="java.math.BigDecimal" isForPrompting="false"/>

  <queryString><![CDATA[SELECT ... WHERE (( PRO.CODPROD = $P{P0} )) ORDER BY "Descrição_Produto"]]></queryString>
  ...
</jasperReport>
```

---

## 1. Parâmetros de infraestrutura (sempre os mesmos seis)

| Parâmetro | Classe | Para que |
|-----------|--------|----------|
| `OUTPUT_STREAM`, `JASPER_PRINT` | `String` | Infra interna de saída do SankhyaW |
| `NOME_REL` | `String` | Título do relatório, exibido no cabeçalho (`$P{NOME_REL}`) |
| `NOME_MODULO` | `String` | Nome do módulo, em negrito-itálico no cabeçalho |
| `FILTRO_REL` | `String` | Texto descrevendo os filtros aplicados, ecoado no cabeçalho |
| `RESULT_SET` | `br.com.sankhya.modelcore.util.JRDataSetSankhya` | **O datasource Sankhya** — preenche os campos do relatório |

> **`RESULT_SET` é o idioma central das listagens.** O engine preenche o relatório a partir
> desse objeto do model layer, não da conexão JDBC. A `<queryString>` ainda existe para o
> wizard resolver o filtro e os metadados dos campos.

---

## 2. Prompts `Pn` (o filtro que o usuário preenche)

Convenções do wizard:

- Nomeados **`P0`, `P1`, `P2`…** em sequência. Sem `isForPrompting="false"` → perguntam.
- **`<property name="type" value="...">`** define o widget:
  - `I` = inteiro/código (`BigDecimal`)
  - `D` = data (`java.sql.Timestamp`)
- **`<property name="NOMETABELA" value="TGFPRO">`** (ou `nomeTabela`) → transforma o prompt
  num **campo de busca** (lupa) ligado àquela tabela. O usuário escolhe um produto/parceiro
  pelo cadastro. Parâmetros de data **não** têm `NOMETABELA`.
- **`<parameterDescription>`** = rótulo, escrito como o operador lê: `"Cód. Produto ="`,
  `"Início da Execução >="`, `"Parceiro ="`.
- Cada `Pn` tem um espelho **`FILTER_PARAM_n`** (mesma classe, `isForPrompting="false"`) usado
  pelo engine ao costurar o filtro no SQL. Faixas de data ganham placeholders **`:DAT1`/`:DAT2`**.

### Exemplos por tipo

**Filtro por código (com busca):**
```xml
<parameter name="P0" class="java.math.BigDecimal">
  <property name="type" value="I"/>
  <property name="NOMETABELA" value="TGFPAR"/>
  <parameterDescription><![CDATA[Parceiro =]]></parameterDescription>
</parameter>
```

**Faixa de datas:**
```xml
<parameter name="P0" class="java.sql.Timestamp">
  <property name="type" value="D"/>
  <parameterDescription><![CDATA[Início da Execução >=]]></parameterDescription>
</parameter>
<parameter name="P1" class="java.sql.Timestamp">
  <property name="type" value="D"/>
  <parameterDescription><![CDATA[Início da Execução <=]]></parameterDescription>
</parameter>
```

**Sem prompt** (relatório roda sem filtro): apenas os seis parâmetros de infra (como
`relatorio-862` e `863`).

### No SQL, o filtro entra entre parênteses duplos
```sql
WHERE OSE.CODPARC = PAR.CODPARC
  AND (( ITE.INICEXEC >= $P{P0} ) AND ( ITE.INICEXEC <= $P{P1} ) AND ( OSE.CODPARC = $P{P2} ))
```
`$P{Pn}` substitui o **valor** (bind). Use `$P!{Pn}` apenas se precisar injetar texto SQL cru.

---

## 3. Query e campos

```sql
SELECT PRO.DESCRPROD AS "Descrição_do_Produto",
       USU.NOMEUSU   AS "Executante",
       ITE.TEMPGASTO AS "Tempo_Gasto",
       OSE.NUMOS     AS "Número_da_OS",
       CASE WHEN OSE.SITUACAO = 'P' THEN 'Pendente'
            WHEN OSE.SITUACAO = 'R' THEN 'Resolvida'
            WHEN OSE.SITUACAO = 'F' THEN 'Fechada' END AS "Situação"
FROM TCSOSE OSE, TGFPAR PAR, TCSITE ITE, TGFPRO PRO, TSIUSU USU
WHERE ...
ORDER BY "Descrição_do_Produto"
```

- **Os aliases (com acento) viram os nomes dos `<field>`** → `$F{Descrição_do_Produto}`.
- **Decodifique status via `CASE` no SQL** (Situação → 'Pendente'/'Resolvida'…) em vez de
  expressão Jasper.
- `<field>` com a classe do tipo SQL (`String`, `BigDecimal`, `Timestamp`).

Tabelas comuns dessas listagens (módulo Contratos e Serviços):
`TCSOSE` (cabeçalho de OS), `TCSITE` (itens de OS), `TCSERR` (erros/soluções),
`TGFPAR` (parceiro), `TGFPRO` (produto/serviço), `TSIUSU` (usuário/executante).

---

## 4. Cabeçalho padrão (idêntico em todas as listagens)

Na banda `pageHeader` (h≈38), só mudam os X de retrato↔paisagem:
- `$P{NOME_MODULO}` — negrito-itálico, topo-esquerdo.
- `$P{NOME_REL}` — negrito, abaixo.
- `"Página " + $V{PAGE_NUMBER} + " de "` + um segundo campo `evaluationTime="Report"` com
  `""+$V{PAGE_NUMBER}` → "Página X de Y".
- `Emissão:` + `new Date()`.
- `$P{FILTRO_REL}` — itálico, `isStretchWithOverflow="true"`, no rodapé do cabeçalho —
  cresce para mostrar os filtros ativos.

---

## 5. Grupos e o idioma "Registros impressos"

Listagens agrupam com `<group>` (não subreports). Variáveis padrão:

```xml
<!-- contador geral, exibido no summary -->
<variable name="varSummaryRegCount" class="java.lang.Double" calculation="Count">
  <variableExpression><![CDATA[$F{Número_da_OS}]]></variableExpression>
</variable>
<!-- contador por grupo, exibido no groupFooter -->
<variable name="varGroupRegCount_grupo" class="java.lang.Double" calculation="Count"
          resetType="Group" resetGroup="group_Descrição_do_Produto">
  <variableExpression><![CDATA[$F{Número_da_OS}]]></variableExpression>
</variable>
```

Cada grupo carrega `isReprintHeaderOnEachPage="true"`. O `groupFooter` imprime
**"Registros impressos:"** + o contador; o `summary` imprime o total geral. Esse rótulo é a
assinatura das listagens Sankhya.

Subtotais numéricos (quando há valor a somar) seguem a convenção `groupsum_<grupo>_<campo>` e
`reportsum_<campo>`:
```xml
<variable name="reportsum_Tempo_Gasto" class="java.math.BigDecimal" calculation="Sum">
  <variableExpression><![CDATA[$F{Tempo_Gasto}]]></variableExpression>
</variable>
```
O total geral costuma ir na banda **`lastPageFooter`** (presente só quando há soma de relatório).

Níveis de agrupamento dos exemplos: 859 (1 nível: produto), 860 (2: parceiro→serviço),
861 (3: parceiro→situação→produto), 862 (1: produto), 863 (sem grupo, query já agregada com
`SUM ... GROUP BY`).

---

## 6. Fontes Sankhya (PDF idêntico em qualquer servidor)

```xml
<font fontName="br/com/sankhya/modelcore/report/font/arial.ttf"
      pdfFontName="br/com/sankhya/modelcore/report/font/arial.ttf" isPdfEmbedded="true"/>
<font fontName="br/com/sankhya/modelcore/report/font/arialbd.ttf" .../>  <!-- negrito -->
```
Corpo tamanho 7; rótulos negrito em `arialbd.ttf`. O cabeçalho/rodapé pode usar Arial/Courier
com built-ins do PDF.

---

## 7. Particularidades das listagens (vs. documento)

- **Datasource `RESULT_SET`** (`JRDataSetSankhya`), não a conexão direta.
- **Sem `NUNOTA`, sem `PDIR_MODELO`/`SUBREPORT_DIR`, sem subreports** — fluxo único de
  detalhe com `<group>`.
- **Prompts `Pn`** com `type`/`NOMETABELA`/`parameterDescription` são o recurso principal.
- **`FILTRO_REL`** ecoa o filtro no cabeçalho.
- **Agregação por grupo** + "Registros impressos" + total em `lastPageFooter`.
- **Sem imagens/logos/código de barras** — tabela limpa com `<line>` como separador.
- **`encoding=ISO-8859-1`** nesses templates (atenção ao salvar — ver `gotchas.md`).

---

## Receita (criar uma listagem)

1. Comece do template `portrait_template`/`landscape_template` com os seis parâmetros de infra.
2. Escreva a query com aliases nomeando os campos; decodifique status via `CASE`; ordene pela
   chave de cada grupo.
3. Declare um `Pn` por filtro (`type` I/D, `NOMETABELA` quando for código de cadastro,
   `parameterDescription` como rótulo) + o espelho `FILTER_PARAM_n`.
4. Monte o `pageHeader` padrão (módulo, título, página, emissão, `FILTRO_REL`).
5. Crie os `<group>` na ordem desejada, com header (rótulo) e footer ("Registros impressos:" +
   contador, e subtotal se houver valor).
6. Total geral no `summary`/`lastPageFooter`.
7. Use as fontes Sankhya empacotadas. Publique pelo cadastro de Relatórios Formatados.
</content>
