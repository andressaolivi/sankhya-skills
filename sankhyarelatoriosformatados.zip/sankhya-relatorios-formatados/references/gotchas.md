# Armadilhas (gotchas) validadas — Relatórios Formatados

Cada regra tem exemplo ruim → exemplo bom. Consulte antes de entregar qualquer `.jrxml` ou
ao diagnosticar "saiu em branco / deu erro".

---

## Regra 1 — JOIN implícito com FK nulo zera o relatório
**Contexto:** Mestre de documento com join por vírgula a uma tabela opcional (veículo,
vendedor, transportador).
**Regra:** Use **`LEFT JOIN` ANSI** para toda tabela cujo FK pode ser nulo.
**Por quê:** Join por vírgula com igualdade é INNER. Se `CAB.CODVEICULO` é nulo, a condição
`CAB.CODVEICULO = VEI.CODVEICULO` elimina a única linha do cabeçalho → relatório **em branco**.

**Ruim:**
```sql
FROM TGFCAB CAB, TGFVEI VEI, TGFVEN VEN
WHERE CAB.CODVEICULO = VEI.CODVEICULO    -- nota sem veículo → 0 linhas
  AND VEN.CODVEND = CAB.CODVEND
  AND CAB.NUNOTA = $P{NUNOTA}
```
**Bom:**
```sql
FROM TGFCAB CAB
LEFT JOIN TGFVEI VEI ON VEI.CODVEICULO = CAB.CODVEICULO
LEFT JOIN TGFVEN VEN ON VEN.CODVEND   = CAB.CODVEND
WHERE CAB.NUNOTA = $P{NUNOTA}
```

---

## Regra 2 — Logo com caminho absoluto fixo
**Contexto:** Imagem/logo no relatório.
**Regra:** Monte o caminho com **`$P{PDIR_MODELO}`** e use **`onErrorType="Blank"`** (+ root
`whenResourceMissingType="Empty"`).
**Por quê:** Path absoluto (`/home/mgeweb/...`) quebra ao mudar de servidor/ambiente; um logo
ausente sem `onErrorType` derruba a impressão inteira.

**Ruim:**
```xml
<imageExpression class="java.lang.String"><![CDATA["/home/mgeweb/repositorio/logos/logo.jpg"]]></imageExpression>
```
**Bom:**
```xml
<image onErrorType="Blank">
  <imageExpression class="java.lang.String"><![CDATA[$P{PDIR_MODELO} + "logo.jpg"]]></imageExpression>
</image>
```

---

## Regra 3 — Subreport não encontrado / não compilado
**Contexto:** Mestre que embute subreports.
**Regra:** Compile **cada** `.jrxml` em `.jasper`, publique no diretório que o `SUBREPORT_DIR`
resolve, e garanta que o **nome do `.jasper` casa** com o usado no `subreportExpression`.
**Por quê:** O engine carrega o binário `.jasper`; se faltar ou o nome divergir, dá erro de
recurso/`FileNotFound`.

**Ruim:**
```xml
<subreportExpression><![CDATA[$P{SUBREPORT_DIR} + "itens.jasper"]]></subreportExpression>
<!-- mas o arquivo publicado é ITENS_PEDIDO_DE_VENDA.jasper -->
```
**Bom:**
```xml
<subreportExpression class="java.lang.String"><![CDATA[$P{SUBREPORT_DIR} + "ITENS_PEDIDO_DE_VENDA.jasper"]]></subreportExpression>
```
> DANFE usa path relativo literal `"./danfe_retrato_sub.jasper"` em vez de `SUBREPORT_DIR` —
> mantenha o padrão do conjunto que está editando.

---

## Regra 4 — Esqueceu a conexão no subreport
**Contexto:** Subreport com query própria.
**Regra:** Sempre passe **`<connectionExpression>$P{REPORT_CONNECTION}</connectionExpression>`**.
**Por quê:** Sem a conexão, o subreport não tem como rodar o próprio SQL → vazio ou erro.

**Bom:**
```xml
<subreport isUsingCache="true">
  <subreportParameter name="NUNOTA"><subreportParameterExpression><![CDATA[$P{NUNOTA}]]></subreportParameterExpression></subreportParameter>
  <connectionExpression><![CDATA[$P{REPORT_CONNECTION}]]></connectionExpression>
  <subreportExpression class="java.lang.String"><![CDATA[$P{SUBREPORT_DIR} + "NOME.jasper"]]></subreportExpression>
</subreport>
```

---

## Regra 5 — Total do rodapé vem zerado
**Contexto:** Mestre exibe totais somados no subreport de itens.
**Regra:** Declare a variável `Sum` **vazia** no mestre e use **`<returnValue>`** no
`<subreport>` para subir o valor.
**Por quê:** A soma é calculada no subreport (que tem as linhas). Sem `returnValue`, a
variável do mestre nunca recebe nada.

**Ruim:** mestre tenta `<variableExpression>$F{TOTALITEM}</variableExpression>` — mas o mestre
não tem o campo dos itens.
**Bom:**
```xml
<!-- no mestre -->
<variable name="TOTAL_PRODUTO" class="java.math.BigDecimal" calculation="Sum"/>
<!-- no subreport element -->
<returnValue subreportVariable="TOTAL_PRODUTO" toVariable="TOTAL_PRODUTO" calculation="Sum"/>
```

---

## Regra 6 — Subtotal de grupo errado por falta de `ORDER BY`
**Contexto:** Relatório com `<group>`.
**Regra:** A `<queryString>` **deve** ter `ORDER BY` pela mesma expressão do grupo.
**Por quê:** Jasper agrupa assumindo dados pré-ordenados; sem ordenar, o mesmo valor de grupo
aparece em blocos separados e os subtotais saem fragmentados/errados.

**Ruim:** `<group><groupExpression>$F{CODPARC}</groupExpression>` com query sem `ORDER BY CODPARC`.
**Bom:** `... ORDER BY CODPARC, DTNEG, NUMNOTA, DESDOBRAMENTO`.

---

## Regra 7 — Total de grupo no header sem avaliação deferida
**Contexto:** Relatório-resumo (uma linha por grupo, sem `<detail>`), total no `groupHeader`.
**Regra:** Use **`evaluationTime="Group" evaluationGroup="NOME"`** no `textField` do total.
**Por quê:** O header imprime **antes** das linhas serem somadas; sem deferir, mostra 0 ou o
valor da primeira linha.

**Bom:**
```xml
<textField evaluationTime="Group" evaluationGroup="PARCEIRO" pattern="#,##0.00">
  <textFieldExpression><![CDATA[$V{VLRDESDOB_4}]]></textFieldExpression>
</textField>
```

---

## Regra 8 — `$P{}` vs `$P!{}`
**Contexto:** Parâmetro dentro do SQL.
**Regra:** Use **`$P{x}`** para o **valor** (bind, seguro). Use **`$P!{x}`** só para injetar
**texto SQL cru** (cláusula dinâmica) — e ciente do risco de SQL injection.
**Por quê:** `$P!{}` concatena texto literal; usado por engano com valor do usuário vira buraco
de segurança e erro de sintaxe.

**Bom (valor):** `WHERE CAB.NUNOTA = $P{NUNOTA}`
**Bom (trecho dinâmico controlado):** `ORDER BY $P!{ORDITENS}`

---

## Regra 9 — `RECDESP` é Integer (1/−1), não 'R'/'D'
**Contexto:** Filtro financeiro em `TGFFIN`.
**Regra:** `RECDESP = 1` (receita/a receber), `RECDESP = -1` ou `2` (despesa/a pagar)
conforme o contexto. Nunca `'R'`/`'D'`.
**Por quê:** É coluna numérica; comparar com string não filtra nada.

**Ruim:** `WHERE FIN.RECDESP = 'R'`
**Bom:** `WHERE FIN.RECDESP = 1`

---

## Regra 10 — Encoding ISO-8859-1 × arquivo salvo em UTF-8
**Contexto:** Templates de listagem declaram `ireport.encoding=ISO-8859-1`.
**Regra:** Mantenha o encoding **declarado** consistente com como o arquivo é **gravado**.
**Por quê:** Acentos (ç, ã, í) saem corrompidos (mojibake `Ã§`, `ï¿½`) se o arquivo for
salvo em UTF-8 mas declarar ISO-8859-1 (ou vice-versa).

**Bom:** ao editar um template `ISO-8859-1`, salve em ISO-8859-1; ao criar novo, prefira
`<?xml version="1.0" encoding="UTF-8"?>` + `ireport.encoding=UTF-8` consistentes.

---

## Regra 11 — `isBlankWhenNull` ausente em campo nulo
**Contexto:** Campos que podem ser nulos (data de baixa, parcela, desconto).
**Regra:** Ponha **`isBlankWhenNull="true"`** no `<textField>`.
**Por quê:** Sem isso, aparece "null" ou `0,00` indesejado; em expressões pode dar
`NullPointerException`.

**Bom:**
```xml
<textField pattern="dd/MM/yyyy" isBlankWhenNull="true">
  <textFieldExpression class="java.sql.Timestamp"><![CDATA[$F{DHBAIXA}]]></textFieldExpression>
</textField>
```

---

## Regra 12 — Margem de subreport diferente de zero
**Contexto:** `.jrxml` de subreport.
**Regra:** **`leftMargin=rightMargin=topMargin=bottomMargin=0`** e `columnWidth` igual à
largura do elemento que o hospeda.
**Por quê:** O subreport é renderizado na origem do elemento do mestre; margens próprias
deslocam e desalinham colunas/grade.

---

## Regra 13 — DANFE: chave usa `PK_NUNOTA`, não `NUNOTA`
**Contexto:** Editar/criar DANFE.
**Regra:** O conjunto DANFE usa **`PK_NUNOTA`** como chave (e `IMPITENSNFE`). Pedido/orçamento
usam `NUNOTA`. Não troque os nomes.
**Por quê:** O parâmetro injetado precisa bater com o nome esperado pela plataforma naquele
tipo de modelo.

---

## Regra 14 — QR Code na DANFE de NF-e (modelo 55)
**Contexto:** Código de barras da DANFE.
**Regra:** NF-e modelo 55 usa **somente Code-128C** da chave (44 dígitos). **Não** coloque QR
Code — QR é exclusivo da **NFC-e (modelo 65)**.
**Por quê:** Inserir QR numa DANFE 55 é não-conformidade; o layout legal não prevê.

---

## Regra 15 — Tipo do `<field>` divergente do SQL
**Contexto:** Declaração de campos.
**Regra:** A `class` do `<field>` deve casar com o tipo retornado pela query (`BigDecimal`,
`Double`, `Timestamp`, `String`, `Integer`/`Short`).
**Por quê:** Divergência causa `ClassCastException` ou formatação quebrada. Atenção: em alguns
financeiros `VLRDESDOB` é `java.lang.Double`; em outros é `BigDecimal` — siga o que a query
retorna e mantenha a variável `Sum` no mesmo tipo.

---

## Regra 16 — Confirme nomes de tabela/coluna no dicionário
**Contexto:** Escrever a `<queryString>`.
**Regra:** Não invente colunas. Confirme na skill **`sankhya-dicionario`**. Exemplos de
pegadinha: **`TGFTIT`** (tipo de título) × `TGFTIPTIT`; `NUNOTA` × `NUMNOTA`;
`VLRDESDOB` (parcela) × `VLRNOTA` (nota).
**Por quê:** Coluna inexistente → "Nome de coluna inválido" e relatório não roda.

---

## Checklist final antes de entregar

- [ ] Tabelas opcionais com `LEFT JOIN` (Regra 1)
- [ ] Logo via `$P{PDIR_MODELO}` + `onErrorType="Blank"` (Regra 2)
- [ ] Subreports compilados, nome do `.jasper` casa, no `SUBREPORT_DIR` (Regra 3)
- [ ] `$P{REPORT_CONNECTION}` em todo subreport (Regra 4)
- [ ] `returnValue` para totais que sobem ao mestre (Regra 5)
- [ ] `ORDER BY` casa com cada `<group>` (Regra 6)
- [ ] `evaluationTime="Group"` em total de header de resumo (Regra 7)
- [ ] `$P{}` para valor, `$P!{}` só para SQL dinâmico (Regra 8)
- [ ] `RECDESP` numérico (Regra 9)
- [ ] Encoding consistente (Regra 10)
- [ ] `isBlankWhenNull` nos campos nulos (Regra 11)
- [ ] Subreport com margem 0 (Regra 12)
- [ ] DANFE: `PK_NUNOTA`, Code-128, sem QR (Regras 13–14)
- [ ] `class` do field casa com o SQL (Regra 15)
- [ ] Tabelas/colunas confirmadas no dicionário (Regra 16)
</content>
