# Anatomia de um `.jrxml` (JasperReports no Sankhya)

Um `.jrxml` é XML com uma ordem fixa de elementos. Esta é a estrutura mínima de um relatório
Sankhya, com as convenções da plataforma anotadas.

```xml
<?xml version="1.0" encoding="UTF-8"?>
<jasperReport xmlns="http://jasperreports.sourceforge.net/jasperreports"
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:schemaLocation="http://jasperreports.sourceforge.net/jasperreports
        http://jasperreports.sourceforge.net/xsd/jasperreport.xsd"
    name="MEU_RELATORIO"
    pageWidth="842" pageHeight="595" orientation="Landscape"
    columnWidth="814" leftMargin="14" rightMargin="14" topMargin="20" bottomMargin="20">

  <!-- 1. Propriedades de editor (iReport) -->
  <property name="ireport.encoding" value="UTF-8"/>
  <property name="ireport.scriptlethandling" value="0"/>

  <!-- 2. Imports usados nas expressões -->
  <import value="net.sf.jasperreports.engine.*"/>
  <import value="java.util.*"/>
  <import value="com.sankhya.util.StringUtils"/>

  <!-- 3. Parâmetros -->
  <parameter name="NUNOTA" class="java.math.BigDecimal"/>
  <parameter name="PDIR_MODELO" class="java.lang.String">
    <defaultValueExpression><![CDATA["C://"]]></defaultValueExpression>
  </parameter>
  <parameter name="SUBREPORT_DIR" class="java.lang.String" isForPrompting="false">
    <defaultValueExpression><![CDATA["./"]]></defaultValueExpression>
  </parameter>

  <!-- 4. Query SQL -->
  <queryString><![CDATA[SELECT ... FROM TGFCAB CAB WHERE CAB.NUNOTA = $P{NUNOTA}]]></queryString>

  <!-- 5. Campos (colunas da query) -->
  <field name="NUMNOTA" class="java.math.BigDecimal"/>
  <field name="NOMEPARC" class="java.lang.String"/>

  <!-- 6. Variáveis (agregações, contadores) -->
  <variable name="TOTAL" class="java.math.BigDecimal" calculation="Sum">
    <variableExpression><![CDATA[$F{VLRNOTA}]]></variableExpression>
  </variable>

  <!-- 7. Grupos (quebras/subtotais) -->
  <group name="PARCEIRO">
    <groupExpression><![CDATA[$F{CODPARC}]]></groupExpression>
    <groupHeader><band height="14">...</band></groupHeader>
    <groupFooter><band height="20">...</band></groupFooter>
  </group>

  <!-- 8. Bandas (na ordem de renderização) -->
  <background><band/></background>
  <title><band height="50">...</band></title>
  <pageHeader><band height="30">...</band></pageHeader>
  <columnHeader><band height="20">...</band></columnHeader>
  <detail><band height="15">...</band></detail>
  <columnFooter><band/></columnFooter>
  <pageFooter><band height="27">...</band></pageFooter>
  <lastPageFooter><band/></lastPageFooter>
  <summary><band height="92">...</band></summary>
</jasperReport>
```

> A **ordem dos elementos importa** no schema JasperReports: properties → imports →
> parameters → queryString → fields → variables → groups → bandas. Trocar a ordem quebra a
> compilação.

---

## 1. Root `<jasperReport>` — geometria da página

| Atributo | Significado | Valores Sankhya comuns |
|----------|-------------|------------------------|
| `name` | Nome interno do relatório | `PEDIDO_DE_VENDA`, `danfe_retrato`, `landscape_template` |
| `pageWidth`/`pageHeight` | Tamanho em pontos (1 pt = 1/72 pol) | A4 retrato 595×842; A4 paisagem 842×595 |
| `orientation` | `Portrait` (padrão) ou `Landscape` | — |
| `columnWidth` | Largura útil = pageWidth − margens | 814 (paisagem), 555/567 (retrato) |
| `leftMargin`/`rightMargin`/`topMargin`/`bottomMargin` | Margens | Mestre: 14/14/20/20. **Subreport: 0/0/0/0** |
| `language` | Linguagem de expressão | `groovy` (financeiros) ou Java (documentos) |
| `whenResourceMissingType` | O que fazer se faltar recurso (logo) | `Empty` (não quebra) |
| `isFloatColumnFooter` | Rodapé "flutua" abaixo da última linha | `true` em DRE/DRO |

> **Subreport sempre com margem zero** e `columnWidth` = largura do elemento que o hospeda no
> mestre. O subreport é posicionado na origem do host; margem própria desalinha tudo.

---

## 2. `<parameter>` — entradas

```xml
<parameter name="NUNOTA" class="java.math.BigDecimal"/>                 <!-- injetado -->
<parameter name="SUBREPORT_DIR" class="java.lang.String" isForPrompting="false">
  <defaultValueExpression><![CDATA["./"]]></defaultValueExpression>
</parameter>
<parameter name="P0" class="java.math.BigDecimal">                       <!-- prompt -->
  <property name="type" value="I"/>
  <property name="NOMETABELA" value="TGFPRO"/>
  <parameterDescription><![CDATA[Cód. Produto =]]></parameterDescription>
</parameter>
```

- `isForPrompting="false"` → não pergunta ao usuário (parâmetro de plataforma ou interno).
- `<defaultValueExpression>` → valor default (string entre aspas, expressão Java/Groovy).
- `<property name="type">` → tipo do prompt no wizard: `I` inteiro/código, `D` data.
- `<property name="NOMETABELA">` / `nomeTabela` → transforma o prompt em **campo de busca**
  ligado àquela tabela (lupa de pesquisa).
- `<parameterDescription>` → rótulo exibido no prompt (escreva como o operador: `"Parceiro ="`).

Referência em expressões: `$P{nome}`. **`$P{nome}` substitui o valor como bind**;
**`$P!{nome}` substitui o texto cru no SQL** (use só para injetar trechos de SQL dinâmico).

---

## 3. `<queryString>` — SQL contra o banco Sankhya

```xml
<queryString><![CDATA[
SELECT CAB.NUNOTA, CAB.NUMNOTA, PAR.NOMEPARC, CAB.VLRNOTA
FROM TGFCAB CAB
INNER JOIN TGFPAR PAR ON PAR.CODPARC = CAB.CODPARC
WHERE CAB.NUNOTA = $P{NUNOTA}
ORDER BY CAB.DTNEG
]]></queryString>
```

- Sempre dentro de `<![CDATA[ ... ]]>`.
- Os **aliases de coluna viram os nomes dos `<field>`** (inclusive com acento, ex.:
  `SUM(X) AS "Tempo_Gasto"` → `$F{Tempo_Gasto}`).
- Prefira **ANSI JOIN** a join por vírgula (ver `gotchas.md` — join implícito zera o
  relatório quando o FK é nulo).
- Confirme nomes de tabela/coluna na skill `sankhya-dicionario`.

---

## 4. `<field>` — colunas da query

```xml
<field name="NUMNOTA" class="java.math.BigDecimal"/>
<field name="DTVENC" class="java.sql.Timestamp"/>
<field name="NOMEPARC" class="java.lang.String"/>
```

A `class` deve casar com o tipo SQL: `java.lang.String`, `java.math.BigDecimal`,
`java.lang.Double`, `java.lang.Integer`/`Short`, `java.sql.Timestamp`. Referência: `$F{nome}`.

---

## 5. `<variable>` — agregações e cálculos

```xml
<!-- soma geral (resetType padrão = Report) -->
<variable name="TOTAL_GERAL" class="java.math.BigDecimal" calculation="Sum">
  <variableExpression><![CDATA[$F{VLRDESDOB}]]></variableExpression>
</variable>

<!-- subtotal por grupo -->
<variable name="SUBTOTAL" class="java.math.BigDecimal" calculation="Sum"
          resetType="Group" resetGroup="PARCEIRO">
  <variableExpression><![CDATA[$F{VLRDESDOB}]]></variableExpression>
</variable>

<!-- contador de registros -->
<variable name="QTD" class="java.lang.Integer" calculation="Count">
  <variableExpression><![CDATA[$F{NUNOTA}]]></variableExpression>
</variable>
```

| Atributo | Valores | Uso |
|----------|---------|-----|
| `calculation` | `Sum`, `Count`, `Average`, `Highest`, `Lowest`, `Nothing` | tipo de agregação |
| `resetType` | `Report` (padrão), `Group`, `Page`, `Column`, `None` | escopo de acumulação |
| `resetGroup` | nome do `<group>` | obrigatório quando `resetType="Group"` |
| `incrementType` | `None`, `Group`, `Page`, `Report` | quando incrementa |

- **Total geral:** `Sum` sem `resetType` (acumula no relatório todo) → banda `summary`.
- **Subtotal:** `Sum` + `resetType="Group"` + `resetGroup` → banda `groupFooter`.
- **Total com sinal (DRE):** `variableExpression` com `VLRDESDOB * RECDESP` (receita +1,
  despesa −1) soma o resultado líquido num único acumulador (ver `analitico_financeiro.md`).

---

## 6. `<group>` — quebras e subtotais

```xml
<group name="PARCEIRO" isReprintHeaderOnEachPage="true" isStartNewPage="false">
  <groupExpression><![CDATA[$F{CODPARC}]]></groupExpression>
  <groupHeader>
    <band height="14">
      <textField><reportElement x="0" y="0" width="300" height="12"/>
        <textFieldExpression><![CDATA[$F{CODPARC}+" - "+$F{RAZAOSOCIAL}]]></textFieldExpression>
      </textField>
    </band>
  </groupHeader>
  <groupFooter>
    <band height="20">
      <staticText><reportElement x="300" y="2" width="60" height="12"/>
        <text><![CDATA[PARCIAL:]]></text></staticText>
      <textField pattern="#,##0.00"><reportElement x="360" y="2" width="100" height="12"/>
        <textFieldExpression><![CDATA[$V{SUBTOTAL}]]></textFieldExpression>
      </textField>
    </band>
  </groupFooter>
</group>
```

Regras de ouro do agrupamento:
1. A query **precisa estar ordenada** pela mesma expressão do grupo (`ORDER BY CODPARC...`).
   Jasper agrupa assumindo dados pré-ordenados — sem `ORDER BY` o subtotal sai errado.
2. `isReprintHeaderOnEachPage="true"` → repete o cabeçalho do grupo a cada quebra de página.
3. `isStartNewPage="true"` → cada grupo começa em página nova.
4. Para **relatório-resumo** (uma linha por grupo, sem `<detail>`): coloque o total no
   `groupHeader` com `evaluationTime="Group" evaluationGroup="PARCEIRO"` — isso adia o
   cálculo até o grupo inteiro ser lido, permitindo o total aparecer no cabeçalho.

---

## 7. Bandas — ordem de renderização

| Banda | Quando imprime | Uso típico Sankhya |
|-------|----------------|--------------------|
| `background` | Atrás de tudo, toda página | Marca d'água (ex.: "DANFE em contingência") |
| `title` | Uma vez, no início | Canhoto da DANFE; faixa-título do DRE |
| `pageHeader` | Topo de cada página | Cabeçalho da listagem (módulo, título, filtros, página) |
| `columnHeader` | Antes do detalhe, cada página | Títulos das colunas |
| `groupHeader` | A cada novo valor do grupo | Rótulo do grupo |
| `detail` | Uma vez por linha da query | A linha de dados (ou subreport de itens) |
| `groupFooter` | Ao fim de cada grupo | Subtotal "PARCIAL:" |
| `columnFooter` | Fim da coluna | — |
| `pageFooter` | Rodapé de cada página | "Página X de Y" |
| `lastPageFooter` | Rodapé só da última página | Total final flutuante (DRE) |
| `summary` | Uma vez, ao final | Totais gerais, observação, subreport financeiro |

---

## 8. Elementos dentro das bandas

```xml
<staticText>                            <!-- texto fixo -->
  <reportElement x="0" y="0" width="100" height="12"/>
  <textElement textAlignment="Left"/>
  <text><![CDATA[CLIENTE:]]></text>
</staticText>

<textField pattern="#,##0.00" isBlankWhenNull="true">   <!-- valor dinâmico -->
  <reportElement x="100" y="0" width="100" height="12"/>
  <textFieldExpression class="java.math.BigDecimal"><![CDATA[$F{VLRNOTA}]]></textFieldExpression>
</textField>

<line><reportElement x="0" y="13" width="555" height="0"/></line>   <!-- linha/régua -->

<image onErrorType="Blank">                                          <!-- imagem/logo -->
  <reportElement x="0" y="0" width="120" height="40"/>
  <imageExpression class="java.lang.String"><![CDATA[$P{PDIR_MODELO} + "logo.jpg"]]></imageExpression>
</image>
```

- **`reportElement`** — posicionamento absoluto: `x`, `y`, `width`, `height` (em pontos,
  relativos ao canto superior esquerdo da banda).
- **Máscaras `pattern`:** `#,##0.00` (moeda BR), `#,##0.00;-#,##0.00` (negativo com sinal),
  `dd/MM/yyyy` (data), `dd/MM/yyyy HH:mm` (data+hora), `000` (zero-padding/CST).
- **`isBlankWhenNull="true"`** — suprime "null"/0 quando o campo é nulo. Use sempre.
- **`isStretchWithOverflow="true"`** + `stretchType="RelativeToTallestObject"` — campos de
  texto que crescem (descrições longas, observação) sem cortar.
- **`printWhenExpression`** — imprime a banda/elemento só quando a condição (Boolean) é
  verdadeira. Ex.: `new Boolean($V{PAGE_NUMBER}.intValue()==1)`.

---

## 9. Fontes Sankhya (listagens do wizard)

As listagens usam **TTFs empacotados no classpath**, para o PDF embutir a fonte e sair igual
em qualquer servidor:

```xml
<font fontName="br/com/sankhya/modelcore/report/font/arial.ttf"
      pdfFontName="br/com/sankhya/modelcore/report/font/arial.ttf" isPdfEmbedded="true"/>
<font fontName="br/com/sankhya/modelcore/report/font/arialbd.ttf"
      pdfFontName="br/com/sankhya/modelcore/report/font/arialbd.ttf" isPdfEmbedded="true"/>  <!-- negrito -->
```

Corpo costuma ser tamanho 7; rótulos em negrito usam `arialbd.ttf`. Documentos clássicos
(pedido/DANFE) usam fontes comuns (Arial/Courier) com built-ins do PDF.

---

## Checklist ao montar a estrutura

- [ ] Geometria certa (A4, margens; subreport com margem 0)
- [ ] Parâmetros de plataforma declarados (`NUNOTA`/`PK_NUNOTA`, `PDIR_MODELO`, `SUBREPORT_DIR`)
- [ ] Query com `<![CDATA[]]>`, ANSI JOIN, filtro pela chave, `ORDER BY` casando com os grupos
- [ ] `<field>` com classe correta para cada coluna
- [ ] Variáveis de subtotal (`resetType="Group"`) e total geral (sem reset)
- [ ] Grupos com header/footer e `ORDER BY` correspondente
- [ ] `pattern` e `isBlankWhenNull` em todo campo numérico/data
- [ ] Logo via `$P{PDIR_MODELO}` + `onErrorType="Blank"` (nunca path fixo)
</content>
