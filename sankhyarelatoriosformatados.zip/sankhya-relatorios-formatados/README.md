# sankhya-relatorios-formatados

Skill de conhecimento sobre os **Relatórios Formatados do ERP Sankhya** para uso no Claude.ai.

Voltada para consultores, parceiros e desenvolvedores que **criam, editam e depuram** modelos
de impressão em JasperReports (`.jrxml`/`.jasper`) — documentos de nota e listagens/analíticos.

## O que cobre

A construção dos modelos JasperReports usados pelo motor de impressão do Sankhya, com as
**convenções da plataforma** (parâmetros injetados, datasource, helpers, fontes empacotadas):

- **Documentos mestre-detalhe** — espelho de pedido/orçamento, recibo, modelo de nota:
  `NUNOTA`, subreports em cascata (cabeçalho → itens → financeiro), `returnValue`,
  helpers `com.sankhya.util.StringUtils`
- **DANFE** (NF-e modelo 55) — layout fiscal legal, `DanfeUtils`, código de barras Code-128
  da chave de acesso, `printWhenExpression`, contingência/ISSQN
- **Listagens (wizard)** — prompts `P0/P1` (`type` I/D, `NOMETABELA`),
  `RESULT_SET`/`JRDataSetSankhya`, grupos e o idioma "Registros impressos"
- **Analítico financeiro e DRE/DRO** — quebra/subtotais, total geral, total com sinal
  (`VLRDESDOB*RECDESP`), resumo com `evaluationTime="Group"`
- **Parâmetros injetados** pela plataforma — `PDIR_MODELO`, `SUBREPORT_DIR`,
  `REPORT_CONNECTION`, `RESULT_SET`
- **Armadilhas validadas** — JOIN implícito que zera o relatório, logo com path fixo,
  encoding ISO-8859-1, `$P{}` × `$P!{}`, subreport não compilado

## Origem do conteúdo

Compilado a partir de:

- **Modelos `.jrxml` reais** do Sankhya (pedido mestre-detalhe, DANFE retrato, listagens do
  módulo Contratos e Serviços, analíticos financeiros "Data Base" e DRO)
- Conhecimento de **JasperReports/iReport** aplicado às convenções do Sankhya
- Experiência prática de implementação em projetos de consultoria

Não inclui código-fonte do produto nem catálogo interno — apenas os padrões usados no dia a
dia para construir relatórios formatados.

## Versão

Voltada para a família **Sankhya Om 4.x** (SankhyaW). Os modelos foram desenhados em **iReport**
(propriedades `ireport.*`); abrem também no **Jaspersoft Studio**. Algumas assinaturas de
helpers (`DanfeUtils`, `StringUtils`) e nomes de parâmetros podem variar entre versões —
sempre validar contra o ambiente real do cliente.

## Estrutura

- `SKILL.md` — manifesto da skill (índice, regras, gatilhos)
- `README.md` — este arquivo
- `references/conceitos.md` — o que são, ciclo `.jrxml`→`.jasper`, parâmetros injetados
- `references/estrutura_jrxml.md` — anatomia do `.jrxml` (bandas, fields, variables, groups)
- `references/relatorio_documento.md` — mestre-detalhe (pedido): `NUNOTA`, subreports, `returnValue`
- `references/danfe_fiscal.md` — DANFE NF-e: layout legal, `DanfeUtils`, Code-128
- `references/relatorio_lista.md` — listagem wizard: `Pn`, `RESULT_SET`, grupos
- `references/analitico_financeiro.md` — quebra/subtotal, DRE/DRO, total com sinal
- `references/gotchas.md` — armadilhas validadas com exemplo ruim → bom
- `references/indice.md` — mapa de navegação + dicionário de idiomas
- `LICENSE` — licença MIT

## Uso

1. Baixe o `.zip` do release (ou clone o repositório).
2. No Claude.ai, vá em **Settings → Capabilities → Skills**.
3. **Upload skill** apontando para o `.zip`.
4. Pronto — o Claude passa a ajudar a criar/editar/depurar relatórios formatados do Sankhya
   usando este conhecimento como base.

## Skills relacionadas

- `sankhya-dicionario` — para confirmar tabelas e colunas usadas na query do relatório
- `sankhya-funcionamento` — para entender o fluxo/configuração por trás dos dados impressos
- `sankhya-api-java` — para customização Java (Ações, Eventos); fora do escopo de impressão

## Limitações

- Cobertura de **padrões públicos de construção de relatórios**, não da implementação interna
  do motor de impressão do produto.
- Helpers internos (`DanfeUtils`, `StringUtils`, `JRDataSetSankhya`) **não têm garantia de
  estabilidade** entre versões — exemplos podem precisar de ajuste em upgrades.
- A DANFE tem **layout legalmente regulado** — use o modelo padrão do Sankhya como base e
  altere apenas o necessário.
- Esta skill é mantida pela comunidade, **não tem vínculo oficial** com a Sankhya.

## Aviso legal

Sankhya, Sankhya Om e marcas relacionadas são propriedade da **Sankhya Gestão de Negócios**.
Este projeto é um material educativo da comunidade e **não substitui** a documentação oficial
nem implica endosso por parte da fabricante.

## Contribuir

PRs com correções, novos exemplos de `.jrxml` ou cobertura de casos faltantes são bem-vindos.
Mantenha o foco em **padrões públicos** e não envie conteúdo obtido por engenharia reversa que
possa infringir o EULA do produto.

## Licença

MIT — veja `LICENSE`. Aplica-se ao **conteúdo desta skill** (textos, exemplos, estrutura),
não a marcas ou produtos da Sankhya.
</content>
